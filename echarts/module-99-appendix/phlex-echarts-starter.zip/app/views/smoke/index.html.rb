# app/views/smoke/index.html.rb
class Views::Smoke::Index < Views::Base
  def view_template
    div(class: "space-y-10") do
      div do
        h1(class: "text-2xl font-bold mb-1") { "Smoke Test" }
        p(class: "text-neutral-500 text-sm") { "Confirms each layer of the stack is operational." }
      end

      div(class: "grid gap-4") do
        check("Rails", "The page rendered.", true)
        check("Phlex", "This view is a Phlex component.", true)
        check("Tailwind CSS", "The page is styled with utility classes.", true)
        stimulus_check
        echarts_check
      end
    end
  end

  private

  def check(label, detail, passing)
    div(class: "flex items-start gap-4 p-4 rounded-lg border #{passing ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'}") do
      span(class: "text-lg mt-0.5") { passing ? "✓" : "✗" }
      div do
        p(class: "font-medium text-sm") { label }
        p(class: "text-sm text-neutral-600") { detail }
      end
    end
  end

  def stimulus_check
    div(
      class: "flex items-start gap-4 p-4 rounded-lg border border-neutral-200 bg-neutral-50",
      data: { controller: "smoke" }
    ) do
      span(class: "text-lg mt-0.5", data: { smoke_target: "icon" }) { "?" }
      div do
        p(class: "font-medium text-sm") { "Stimulus" }
        p(class: "text-sm text-neutral-600") do
          plain "Click to confirm Stimulus is connected: "
          button(
            class: "underline text-blue-600",
            data: { action: "click->smoke#ping" }
          ) { "Ping" }
          plain " "
          span(data: { smoke_target: "result" }) { "" }
        end
      end
    end
  end

  def echarts_check
    div(class: "p-4 rounded-lg border border-neutral-200 bg-neutral-50") do
      p(class: "font-medium text-sm mb-1") { "ECharts" }
      p(class: "text-sm text-neutral-600 mb-3") { "A chart should render below. If empty, check the browser console." }
      div(
        data: {
          controller: "smoke-chart",
          smoke_chart_options_value: smoke_chart_options.to_json
        },
        style: "height: 200px; width: 100%;"
      )
    end
  end

  def smoke_chart_options
    {
      grid: { top: 20, bottom: 30, left: 40, right: 20 },
      xAxis: { type: "category", data: %w[Jan Feb Mar Apr May Jun] },
      yAxis: { type: "value" },
      series: [{ type: "bar", data: [12, 19, 8, 24, 17, 21] }]
    }
  end
end