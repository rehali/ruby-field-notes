# app/models/cpi_reading.rb
class CpiReading < ApplicationRecord
  validates :category, :year, :quarter, :index_value, presence: true

  scope :by_year,     ->(y) { where(year: y) }
  scope :by_category, ->(c) { where(category: c) }
  scope :ordered,     ->    { order(:year, :quarter) }

  def self.categories = distinct.pluck(:category).sort
  def self.years      = distinct.pluck(:year).sort
end