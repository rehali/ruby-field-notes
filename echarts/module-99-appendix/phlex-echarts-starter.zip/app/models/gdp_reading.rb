# app/models/gdp_reading.rb
class GdpReading < ApplicationRecord
  validates :industry, :year, :quarter, :value_billions, presence: true

  scope :by_year,     ->(y)  { where(year: y) }
  scope :by_industry, ->(i)  { where(industry: i) }
  scope :ordered,     ->     { order(:year, :quarter) }

  def self.industries = distinct.pluck(:industry).sort
  def self.years      = distinct.pluck(:year).sort
end