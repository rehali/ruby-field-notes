# app/models/daily_activity_reading.rb
class DailyActivityReading < ApplicationRecord
  validates :date, :value, presence: true

  scope :ordered,    ->          { order(:date) }
  scope :for_year,   ->(y)       { where(date: Date.new(y)..Date.new(y).end_of_year) }
  scope :for_range,  ->(from, to) { where(date: from..to) }
end