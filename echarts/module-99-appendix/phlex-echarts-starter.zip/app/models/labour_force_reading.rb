# app/models/labour_force_reading.rb
class LabourForceReading < ApplicationRecord
  validates :state, :year, :month, presence: true

  scope :for_state,   ->(s) { where(state: s) }
  scope :by_year,     ->(y) { where(year: y) }
  scope :ordered,     ->    { order(:year, :month) }

  def self.states = distinct.pluck(:state).sort
  def self.years  = distinct.pluck(:year).sort
end