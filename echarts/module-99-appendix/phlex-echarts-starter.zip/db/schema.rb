# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# This file is the source Rails uses to define your schema when running `bin/rails
# db:schema:load`. When creating a new database, `bin/rails db:schema:load` tends to
# be faster and is potentially less error prone than running all of your
# migrations from scratch. Old migrations may fail to apply correctly if those
# migrations use external dependencies or application code.
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema[8.1].define(version: 2026_04_11_014634) do
  create_table "cpi_readings", force: :cascade do |t|
    t.string "category"
    t.datetime "created_at", null: false
    t.decimal "index_value"
    t.integer "quarter"
    t.datetime "updated_at", null: false
    t.integer "year"
  end

  create_table "daily_activity_readings", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.date "date"
    t.datetime "updated_at", null: false
    t.decimal "value"
  end

  create_table "gdp_readings", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.string "industry"
    t.integer "quarter"
    t.datetime "updated_at", null: false
    t.decimal "value_billions"
    t.integer "year"
  end

  create_table "labour_force_readings", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.decimal "employed_thousands"
    t.integer "month"
    t.decimal "participation_rate"
    t.string "state"
    t.decimal "unemployed_thousands"
    t.decimal "unemployment_rate"
    t.datetime "updated_at", null: false
    t.integer "year"
  end

  create_table "leading_index_readings", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.decimal "index_value"
    t.integer "month"
    t.datetime "updated_at", null: false
    t.integer "year"
  end
end
