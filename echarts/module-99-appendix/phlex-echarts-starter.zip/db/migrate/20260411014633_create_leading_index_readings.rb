class CreateLeadingIndexReadings < ActiveRecord::Migration[8.1]
  def change
    create_table :leading_index_readings do |t|
      t.integer :year
      t.integer :month
      t.decimal :index_value

      t.timestamps
    end
  end
end
