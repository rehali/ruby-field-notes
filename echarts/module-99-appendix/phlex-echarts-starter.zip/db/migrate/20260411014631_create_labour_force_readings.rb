class CreateLabourForceReadings < ActiveRecord::Migration[8.1]
  def change
    create_table :labour_force_readings do |t|
      t.string :state
      t.integer :year
      t.integer :month
      t.decimal :employed_thousands
      t.decimal :unemployed_thousands
      t.decimal :participation_rate
      t.decimal :unemployment_rate

      t.timestamps
    end
  end
end
