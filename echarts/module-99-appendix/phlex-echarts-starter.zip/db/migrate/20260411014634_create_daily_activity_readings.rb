class CreateDailyActivityReadings < ActiveRecord::Migration[8.1]
  def change
    create_table :daily_activity_readings do |t|
      t.date :date
      t.decimal :value

      t.timestamps
    end
  end
end
