class CreateCpiReadings < ActiveRecord::Migration[8.1]
  def change
    create_table :cpi_readings do |t|
      t.string :category
      t.integer :year
      t.integer :quarter
      t.decimal :index_value

      t.timestamps
    end
  end
end
