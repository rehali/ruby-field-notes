class CreateGdpReadings < ActiveRecord::Migration[8.1]
  def change
    create_table :gdp_readings do |t|
      t.string :industry
      t.integer :year
      t.integer :quarter
      t.decimal :value_billions

      t.timestamps
    end
  end
end
