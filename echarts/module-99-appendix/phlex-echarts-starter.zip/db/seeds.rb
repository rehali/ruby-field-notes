# db/seeds.rb
require "json"

puts "Seeding GDP readings..."
gdp_data = JSON.parse(File.read(Rails.root.join("db/seeds/gdp_data.json")))
gdp_data.each do |row|
  GdpReading.find_or_create_by!(
    industry: row["industry"],
    year:     row["year"],
    quarter:  row["quarter"]
  ) do |r|
    r.value_billions = row["value_billions"]
  end
end
puts "  #{GdpReading.count} GDP readings seeded."

puts "Seeding labour force readings..."
labour_data = JSON.parse(File.read(Rails.root.join("db/seeds/labour_force_data.json")))
labour_data.each do |row|
  LabourForceReading.find_or_create_by!(
    state: row["state"],
    year:  row["year"],
    month: row["month"]
  ) do |r|
    r.employed_thousands    = row["employed_thousands"]
    r.unemployed_thousands  = row["unemployed_thousands"]
    r.participation_rate    = row["participation_rate"]
    r.unemployment_rate     = row["unemployment_rate"]
  end
end
puts "  #{LabourForceReading.count} labour force readings seeded."

puts "Seeding CPI readings..."
cpi_data = JSON.parse(File.read(Rails.root.join("db/seeds/cpi_data.json")))
cpi_data.each do |row|
  CpiReading.find_or_create_by!(
    category: row["category"],
    year:     row["year"],
    quarter:  row["quarter"]
  ) do |r|
    r.index_value = row["index_value"]
  end
end
puts "  #{CpiReading.count} CPI readings seeded."

puts "Seeding leading index readings..."
leading_data = JSON.parse(File.read(Rails.root.join("db/seeds/leading_index_data.json")))
leading_data.each do |row|
  LeadingIndexReading.find_or_create_by!(
    year:  row["year"],
    month: row["month"]
  ) do |r|
    r.index_value = row["index_value"]
  end
end
puts "  #{LeadingIndexReading.count} leading index readings seeded."

puts "Generating daily activity readings..."
srand(42)
start_date = Date.new(2020, 1, 1)
end_date   = Date.new(2023, 12, 31)
base_value = 100.0
value      = base_value

(start_date..end_date).each do |date|
  day_of_year    = date.yday
  seasonal_bias  = Math.sin((day_of_year / 365.0) * 2 * Math::PI) * 8
  random_walk    = (rand - 0.48) * 3
  value          = (value + random_walk + seasonal_bias * 0.1).clamp(60.0, 160.0)

  DailyActivityReading.find_or_create_by!(date: date) do |r|
    r.value = value.round(2)
  end
end
puts "  #{DailyActivityReading.count} daily activity readings generated."

puts "Done."