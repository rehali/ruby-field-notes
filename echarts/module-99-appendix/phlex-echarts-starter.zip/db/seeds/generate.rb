# db/seeds/generate.rb
#
# Generates seed data JSON files for the phlex-echarts tutorial.
# Run from the Rails root: ruby db/seeds/generate.rb
#
# Output files (gitignored, generated locally):
#   db/seeds/gdp_data.json
#   db/seeds/labour_force_data.json
#   db/seeds/cpi_data.json
#   db/seeds/leading_index_data.json
#   db/seeds/daily_activity_data.json
#
# Deterministic: uses a hand-rolled LCG so output is identical across
# all Ruby versions.

require "json"
require "date"

# ── Deterministic RNG (Linear Congruential Generator) ────────────────────────
# Parameters from Numerical Recipes. Version-independent — does not use
# Ruby's built-in Random, so output is stable across Ruby versions.
class LCG
  M = 2**32
  A = 1664525
  C = 1013904223

  def initialize(seed)
    @state = seed
  end

  # Returns a float in [0, 1)
  def rand
    @state = (A * @state + C) % M
    @state.to_f / M
  end

  # Returns a float in [min, max)
  def rand_float(min, max)
    min + rand * (max - min)
  end

  # Returns an approximation of a normal distribution via Box-Muller
  def rand_normal(mean, sd)
    u1 = [rand, 1e-10].max
    u2 = rand
    z  = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2 * Math::PI * u2)
    mean + z * sd
  end

  def clamp(value, min, max)
    [[value, min].max, max].min
  end
end

rng = LCG.new(42)
output_dir = File.expand_path("../seeds", __dir__)

# ── GDP readings ──────────────────────────────────────────────────────────────
# 10 industries × 4 quarters × 24 years (2000–2023) = 960 records
puts "Generating GDP readings..."

industries = {
  "Agriculture"          => { base: 8.0,   trend: 0.04,  vol: 0.6  },
  "Mining"               => { base: 28.0,  trend: 0.18,  vol: 2.1  },
  "Manufacturing"        => { base: 32.0,  trend: 0.05,  vol: 1.2  },
  "Construction"         => { base: 22.0,  trend: 0.14,  vol: 1.4  },
  "Retail Trade"         => { base: 18.0,  trend: 0.08,  vol: 0.9  },
  "Financial Services"   => { base: 38.0,  trend: 0.22,  vol: 2.4  },
  "Health Care"          => { base: 24.0,  trend: 0.20,  vol: 1.0  },
  "Education"            => { base: 14.0,  trend: 0.12,  vol: 0.6  },
  "Professional Services"=> { base: 20.0,  trend: 0.19,  vol: 1.3  },
  "Public Administration"=> { base: 16.0,  trend: 0.10,  vol: 0.5  },
}

gdp_records = []
industries.each do |industry, cfg|
  value = cfg[:base]
  (2000..2023).each do |year|
    (1..4).each do |quarter|
      shock    = (year == 2020 && quarter == 2) ? -0.12 : 0.0
      seasonal = Math.sin((quarter / 4.0) * 2 * Math::PI) * cfg[:vol] * 0.3
      noise    = (rng.rand - 0.5) * cfg[:vol]
      value    = value * (1 + cfg[:trend] / 4.0 + shock) + seasonal + noise
      value    = [value, cfg[:base] * 0.5].max
      gdp_records << {
        industry:      industry,
        year:          year,
        quarter:       quarter,
        value_billions: value.round(2)
      }
    end
  end
end

File.write(File.join(output_dir, "gdp_data.json"), JSON.pretty_generate(gdp_records))
puts "  #{gdp_records.size} records written to gdp_data.json"

# ── Labour force readings ─────────────────────────────────────────────────────
# 8 states × 12 months × 12 years (2012–2023) = 1,152 records
puts "Generating labour force readings..."

states = {
  "NSW" => { employed_base: 3600.0, ur_base: 5.2 },
  "VIC" => { employed_base: 3000.0, ur_base: 5.6 },
  "QLD" => { employed_base: 2300.0, ur_base: 5.8 },
  "WA"  => { employed_base: 1300.0, ur_base: 4.8 },
  "SA"  => { employed_base:  800.0, ur_base: 6.0 },
  "TAS" => { employed_base:  230.0, ur_base: 6.8 },
  "ACT" => { employed_base:  210.0, ur_base: 3.4 },
  "NT"  => { employed_base:  120.0, ur_base: 4.2 },
}

lf_records = []
states.each do |state, cfg|
  employed = cfg[:employed_base]
  ur       = cfg[:ur_base]

  (2012..2023).each do |year|
    (1..12).each do |month|
      # COVID crash
      if year == 2020 && [4, 5].include?(month)
        employed *= 0.965
        ur       += 1.8
      elsif year == 2020 && (6..8).include?(month)
        employed *= 1.008
        ur       -= 0.4
      else
        employed *= (1 + 0.018 / 12.0)
        ur        = rng.clamp(ur * 0.998 + rng.rand_normal(0, 0.08), 2.0, 12.0)
      end

      # VIC second lockdown
      if state == "VIC" && year == 2020 && (7..9).include?(month)
        employed *= 0.975
        ur       += 0.6
      end

      seasonal      = Math.sin(((month - 1) / 12.0) * 2 * Math::PI) * 15.0
      employed_val  = employed + seasonal + rng.rand_normal(0, employed * 0.003)
      participation = rng.clamp(65.0 + (year - 2012) * 0.05 + rng.rand_normal(0, 0.2), 60.0, 72.0)
      unemployed_val = employed_val * (ur / 100.0) / (1.0 - ur / 100.0)

      lf_records << {
        state:                 state,
        year:                  year,
        month:                 month,
        employed_thousands:    employed_val.round(1),
        unemployed_thousands:  [unemployed_val, 1.0].max.round(1),
        participation_rate:    participation.round(1),
        unemployment_rate:     ur.round(1)
      }
    end
  end
end

File.write(File.join(output_dir, "labour_force_data.json"), JSON.pretty_generate(lf_records))
puts "  #{lf_records.size} records written to labour_force_data.json"

# ── CPI readings ──────────────────────────────────────────────────────────────
# 8 categories × 4 quarters × 32 years (1992–2023) = 1,024 records
puts "Generating CPI readings..."

categories = {
  "Food & Non-Alcoholic Beverages" => { base: 60.0,  trend:  0.030 },
  "Housing"                        => { base: 55.0,  trend:  0.038 },
  "Transport"                      => { base: 58.0,  trend:  0.025 },
  "Health"                         => { base: 52.0,  trend:  0.042 },
  "Education"                      => { base: 48.0,  trend:  0.048 },
  "Recreation & Culture"           => { base: 72.0,  trend:  0.010 },
  "Clothing & Footwear"            => { base: 95.0,  trend: -0.005 },
  "Communication"                  => { base: 130.0, trend: -0.018 },
}

cpi_records = []
categories.each do |category, cfg|
  value = cfg[:base]
  (1992..2023).each do |year|
    (1..4).each do |quarter|
      extra = [2021, 2022].include?(year) ? 0.004 : 0.0
      noise = rng.rand_normal(0, 0.4)
      value = value * (1 + cfg[:trend] / 4.0 + extra) + noise
      value = [value, 20.0].max
      cpi_records << {
        category:    category,
        year:        year,
        quarter:     quarter,
        index_value: value.round(1)
      }
    end
  end
end

File.write(File.join(output_dir, "cpi_data.json"), JSON.pretty_generate(cpi_records))
puts "  #{cpi_records.size} records written to cpi_data.json"

# ── Leading index readings ────────────────────────────────────────────────────
# Monthly 2000–2023 = 288 records
puts "Generating leading index readings..."

leading_records = []
value = 100.0
(2000..2023).each do |year|
  (1..12).each do |month|
    delta = if year == 2008 && month >= 9
              rng.rand_normal(-0.8, 0.3)
            elsif year == 2009 && month <= 6
              rng.rand_normal(-0.4, 0.3)
            elsif year == 2009 && month > 6
              rng.rand_normal(0.5, 0.2)
            elsif year == 2020 && [3, 4].include?(month)
              rng.rand_normal(-3.2, 0.4)
            elsif year == 2020 && (5..8).include?(month)
              rng.rand_normal(1.4, 0.3)
            elsif [2022, 2023].include?(year)
              rng.rand_normal(-0.15, 0.25)
            else
              rng.rand_normal(0.12, 0.22)
            end

    value = rng.clamp(value + delta, 80.0, 125.0)
    leading_records << { year: year, month: month, index_value: value.round(2) }
  end
end

File.write(File.join(output_dir, "leading_index_data.json"), JSON.pretty_generate(leading_records))
puts "  #{leading_records.size} records written to leading_index_data.json"

# ── Daily activity readings ───────────────────────────────────────────────────
# Daily 2018–2023 = 2,191 records
puts "Generating daily activity readings..."

daily_records = []
value   = 100.0
current = Date.new(2018, 1, 1)
last    = Date.new(2023, 12, 31)

while current <= last
  doy      = current.yday
  seasonal = Math.sin((doy / 365.0) * 2 * Math::PI) * 10.0

  drift = if current >= Date.new(2020, 3, 15) && current <= Date.new(2020, 5, 31)
            -0.3
          elsif current >= Date.new(2020, 6, 1) && current <= Date.new(2020, 12, 31)
            0.15
          else
            0.02
          end

  value = rng.clamp(value + drift + seasonal * 0.04 + rng.rand_normal(0, 1.8), 55.0, 165.0)
  daily_records << { date: current.iso8601, value: value.round(2) }
  current = current.next_day
end

File.write(File.join(output_dir, "daily_activity_data.json"), JSON.pretty_generate(daily_records))
puts "  #{daily_records.size} records written to daily_activity_data.json"

puts "\nDone. All files written to db/seeds/."
puts "These files are gitignored — run this script after cloning to regenerate them."