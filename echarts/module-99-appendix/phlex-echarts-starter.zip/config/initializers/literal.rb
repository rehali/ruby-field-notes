# config/initializers/literal.rb
require "literal"