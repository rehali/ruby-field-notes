# config/routes.rb
Rails.application.routes.draw do
  get "smoke", to: "smoke#index", as: :smoke
  get "up" => "rails/health#show", as: :rails_health_check
  root "smoke#index"
end
