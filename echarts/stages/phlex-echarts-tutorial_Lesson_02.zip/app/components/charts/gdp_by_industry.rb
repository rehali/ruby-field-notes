# app/views/components/charts/gdp_by_industry.rb
module Components
  module Charts
    class GdpByIndustry < Components::Chart
      prop :data, _Any, default: -> { {} }

      private

      def chart_options
        ::Chart::Options.new(
          tooltip: { trigger: "axis" },
          legend:  { bottom: 5 },
          x_axis:  { type: "category", data: years },
          y_axis:  { type: "value" },
          grid:    { left: 8, right: 8, bottom: 40, containLabel: true },
          series:  build_series
        )
      end

      def build_series
        @data.map do |industry, values|
          ::Chart::Series::Line.new(
            name: industry,
            data: values
          )
        end
      end

      def years
        (2000..2024).map(&:to_s)
      end
    end
  end
end