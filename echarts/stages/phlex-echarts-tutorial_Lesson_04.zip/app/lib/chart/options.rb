# app/lib/chart/options.rb
module Chart
  class Options
    def initialize(
      title:     nil,
      tooltip:   nil,
      x_axis:    nil,
      y_axis:    nil,
      series:    [],
      legend:    nil,
      grid:      nil,
      color:     nil,
      animation: false,
      **extra
    )
      @title     = title
      @tooltip   = tooltip
      @x_axis    = x_axis
      @y_axis    = y_axis
      @series    = Array(series)
      @legend    = legend
      @grid      = grid
      @color     = color
      @animation = animation
      @extra     = extra
    end

    def to_h
      h = {
        animation: @animation,
        series:    @series.map { |s| resolve(s) }
      }
      h[:color]   = @color           if @color
      h[:title]   = resolve(@title)   if @title
      h[:tooltip] = resolve(@tooltip) if @tooltip
      h[:xAxis]   = resolve(@x_axis)  if @x_axis
      h[:yAxis]   = resolve(@y_axis)  if @y_axis
      h[:legend]  = resolve(@legend)  if @legend
      h[:grid]    = resolve(@grid)    if @grid
      h.merge!(@extra)
      h
    end

    def to_json(*)
      to_h.to_json
    end

    private

    # DSL objects call to_h; plain hashes pass through unchanged.
    # Arrays are resolved element by element.
    def resolve(value)
      case value
      when Array then value.map { |v| resolve(v) }
      when Hash  then value
      else
        value.respond_to?(:to_h) ? value.to_h : value
      end
    end
  end
end