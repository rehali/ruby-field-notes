# app/lib/chart/series/scatter.rb
module Chart
  module Series
    class Scatter < Base
      private
      def series_type = "scatter"
    end
  end
end
