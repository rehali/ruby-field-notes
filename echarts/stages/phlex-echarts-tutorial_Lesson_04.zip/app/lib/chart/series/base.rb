# app/lib/chart/series/base.rb
module Chart
  module Series
    class Base
      def initialize(**opts)
        @opts = opts
      end

      def to_h
        { type: series_type }.merge(resolved_opts)
      end

      private

      def series_type
        raise NotImplementedError, "#{self.class} must implement series_type"
      end

      def resolved_opts
        @opts.transform_values do |v|
          case v
          when Array then v
          when Hash  then v
          else
            v.respond_to?(:to_h) ? v.to_h : v
          end
        end
      end
    end
  end
end
