# app/lib/chart/series/pie.rb
module Chart
  module Series
    class Pie < Base
      private
      def series_type = "pie"
    end
  end
end
