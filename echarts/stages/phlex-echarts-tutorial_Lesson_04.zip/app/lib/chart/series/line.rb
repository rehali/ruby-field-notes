# app/lib/chart/series/line.rb
module Chart
  module Series
    class Line < Base
      private
      def series_type = "line"
    end
  end
end
