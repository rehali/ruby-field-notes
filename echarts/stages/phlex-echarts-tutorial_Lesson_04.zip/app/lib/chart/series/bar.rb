# app/lib/chart/series/bar.rb
module Chart
  module Series
    class Bar < Base
      private
      def series_type = "bar"
    end
  end
end
