# app/views/components/charts/unemployment_rate.rb
module Components
  module Charts
    class UnemploymentRate < Components::Chart
      prop :data, _Any, default: -> { {} }

      private

      def chart_options
        ::Chart::Options.new(
          color:   "warm",
          toolbox: {
            feature: {
              magicType:   { type: ["line", "bar"] },
              saveAsImage: {},
              restore:     {}
            }
          },
          tooltip: { trigger: "axis", formatter: "rate" },
          legend:  { type: "scroll", bottom: 5 },
          x_axis:  { type: "category", data: years },
          y_axis:  { type: "value", axisLabel: { formatter: "rate" } },
          grid:    { bottom: 60, left: 8, right: 8, containLabel: true },
          series:  build_series
        )
      end

      def build_series
        @data.map do |state, rows|
          ::Chart::Series::Line.new(
            name:   state,
            data:   rows.map { |r| r[:rate] },
            smooth: true
          )
        end
      end

      def years
        @data.values.first&.map { |r| r[:year].to_s } || []
      end
    end
  end
end