# app/views/components/charts/labour_force_horizontal.rb
module Components
  module Charts
    class LabourForceHorizontal < Components::Chart
      prop :data, _Any, default: -> { {} }

      private

      def chart_options
        latest = @data.transform_values(&:last)

        ::Chart::Options.new(
          color:   "cool",
          toolbox: { feature: { saveAsImage: {}, restore: {} } },
          tooltip: { trigger: "axis", formatter: "thousands" },
          legend:  { show: false },
          x_axis:  { type: "value", axisLabel: { formatter: "thousands" } },
          y_axis:  { type: "category", data: latest.keys },
          grid:    { left: 8, right: 16, containLabel: true },
          series: [
            ::Chart::Series::Bar.new(
              name: "Employed (#{latest.values.first&.dig(:year)})",
              data: latest.values.map { |r| r[:employed] }
            )
          ]
        )
      end
    end
  end
end