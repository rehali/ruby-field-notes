# app/views/components/charts/labour_force.rb
module Components
  module Charts
    class LabourForce < Components::Chart
      prop :data, _Any, default: -> { {} }

      private

      def chart_options
        ::Chart::Options.new(
          color:   "cool",
          toolbox: {
            feature: {
              magicType:   { type: ["bar", "line", "stack"] },
              saveAsImage: {},
              restore:     {}
            }
          },
          tooltip: { trigger: "axis", formatter: "thousands" },
          legend:  { type: "scroll", bottom: 5 },
          x_axis:  { type: "category", data: years },
          y_axis:  { type: "value", axisLabel: { formatter: "thousands" } },
          grid:    { bottom: 60, left: 8, right: 8, containLabel: true },
          series:  build_series
        )
      end

      def build_series
        @data.map do |state, rows|
          ::Chart::Series::Bar.new(
            name: state,
            data: rows.map { |r| r[:employed] }
          )
        end
      end

      def years
        @data.values.first&.map { |r| r[:year].to_s } || []
      end
    end
  end
end