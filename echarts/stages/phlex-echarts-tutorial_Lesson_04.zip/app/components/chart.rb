# app/views/components/chart.rb
#
# Base class for all chart components.
#
# Props (inherited by every chart component):
#
#   height:     String  — chart container height (default "400px")
#   group:      String  — ECharts group name for linked charts
#   color:      String  — palette override (replaces chart's own palette)
#   select_url: String  — URL to visit when a data point is clicked
#
# All props default to safe values — a chart with no extra props renders
# as a standalone 400px chart using whatever palette chart_options specifies.

class Components::Chart < Components::Base
  prop :height,     String, default: -> { "400px" }
  prop :group,      String, default: -> { "" }
  prop :color,      String, default: -> { "" }
  prop :select_url, String, default: -> { "" }

  def view_template
    options = chart_options.to_h
    options[:color] = @color if @color.present?

    div(class: "p-2 rounded-lg bg-white border border-neutral-200", **@html) do
      div(
        data: {
          controller:                "chart",
          chart_target:              "mount",
          chart_options_value:       options.to_json,
          chart_group_value:         @group,
          chart_select_url_value:    @select_url
        },
        style: "height: #{@height}; width: 100%;"
      )
    end
  end

  private

  def chart_options
    raise NotImplementedError, "#{self.class} must implement chart_options"
  end
end
