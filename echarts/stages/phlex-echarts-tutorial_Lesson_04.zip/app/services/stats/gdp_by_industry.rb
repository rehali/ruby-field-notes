# app/services/stats/gdp_by_industry.rb
module Stats
  module GdpByIndustry
    extend self

    INDUSTRIES = [
      "Mining",
      "Construction",
      "Financial and Insurance Services",
      "Health Care and Social Assistance",
      "Manufacturing"
    ].freeze

    # Returns annual GDP totals per industry:
    # {
    #   "Mining"        => [12.3, 14.1, 18.7, ...],  # 2000, 2001, 2002...
    #   "Construction"  => [8.4, 9.2, 10.1, ...],
    #   ...
    # }
    def call(readings)
      readings
        .select { |r| INDUSTRIES.include?(r.industry) }
        .group_by(&:industry)
        .transform_values do |rows|
        rows
          .group_by(&:year)
          .sort
          .map { |_year, year_rows|
            year_rows.sum { |r| r.value_billions.to_f }.round(1)
          }
      end
    end
  end
end