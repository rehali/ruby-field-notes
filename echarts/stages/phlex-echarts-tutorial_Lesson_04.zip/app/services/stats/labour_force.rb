# app/services/stats/labour_force.rb
module Stats
  module LabourForce
    extend self

    # Returns annual averages per state:
    # {
    #   "New South Wales" => [
    #     { year: 2012, employed: 3562.4, unemployed: 198.1,
    #       participation: 62.3, rate: 5.3 },
    #     ...
    #   ],
    #   ...
    # }
    def call(readings)
      readings
        .group_by(&:state)
        .transform_values do |state_rows|
        state_rows
          .group_by(&:year)
          .map do |year, rows|
          {
            year:          year,
            employed:      avg(rows, :employed_thousands),
            unemployed:    avg(rows, :unemployed_thousands),
            participation: avg(rows, :participation_rate),
            rate:          avg(rows, :unemployment_rate)
          }
        end
          .sort_by { |r| r[:year] }
      end
    end

    private

    def avg(rows, attr)
      values = rows.map { |r| r.send(attr).to_f }.reject(&:zero?)
      return 0.0 if values.empty?
      (values.sum / values.size).round(1)
    end
  end
end