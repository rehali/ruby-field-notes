// app/javascript/charts/custom_chart_palettes.js
//
// Application-specific colour palettes.
// These are merged on top of the base palettes in chart_palettes.js.
// Custom palettes override base palettes when names clash.
//
// Reference a palette by name from Ruby:
//
//   ::Chart::Options.new(color: "brand", series: build_series)
//
// Each palette should contain 12 entries. If a chart has more series
// than palette entries, ECharts cycles back to the first colour.
//
// Example:
//
// export default {
//   brand: [
//     "#0047AB", "#C1121F", "#FFD700", "#2D6A4F", "#6A0572",
//     "#E76F51", "#264653", "#E9C46A", "#F4A261", "#A8DADC",
//     "#457B9D", "#1D3557"
//   ]
// }

export default {}
