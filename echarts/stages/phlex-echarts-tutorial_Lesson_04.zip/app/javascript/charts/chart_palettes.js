// app/javascript/charts/chart_palettes.js
//
// Base palette registry for ECharts charts.
//
// Usage from Ruby:
//
//   ::Chart::Options.new(
//     color:  "cool",
//     series: build_series
//   )
//
// Each palette contains 12 entries. If a chart has more series than palette
// entries, ECharts cycles back to the first colour automatically. This is
// acceptable for most cases. If you need more than 12 distinct colours,
// add an extended palette to custom_chart_palettes.js.
//
// Add application-specific palettes to custom_chart_palettes.js.
// Custom palettes override base palettes when names clash.

import customPalettes from "custom_chart_palettes"

const basePalettes = {

  // Default — ECharts' own palette, familiar and well-balanced.
  // A safe choice when no particular mood is required.
  default: [
    "#5470c6", "#91cc75", "#fac858", "#ee6666", "#73c0de",
    "#3ba272", "#fc8452", "#9a60b4", "#ea7ccc", "#fb8c00",
    "#00acc1", "#8d6e63"
  ],

  // Warm — reds, oranges, and yellows.
  // Suits dashboards conveying energy, urgency, or heat-related data.
  warm: [
    "#d32f2f", "#e64a19", "#f57c00", "#fbc02d", "#c62828",
    "#bf360c", "#e65100", "#ff8f00", "#f9a825", "#ef6c00",
    "#ff7043", "#ffca28"
  ],

  // Cool — blues, greens, and purples.
  // Professional and calm. Well-suited to financial and economic data.
  cool: [
    "#1565c0", "#0277bd", "#00838f", "#2e7d32", "#4527a0",
    "#1976d2", "#0288d1", "#00897b", "#388e3c", "#5e35b1",
    "#42a5f5", "#26c6da"
  ],

  // Earth — warm naturals: browns, tans, sage, and terracotta.
  // Grounded and approachable. Works well for environmental or
  // agricultural data.
  earth: [
    "#6d4c41", "#8d6e63", "#a1887f", "#4e342e", "#795548",
    "#558b2f", "#689f38", "#827717", "#f9a825", "#e65100",
    "#bf360c", "#5d4037"
  ],

  // Pastel — soft, muted tones with reduced saturation.
  // Gentle and accessible. Good for presentations and reports
  // where vivid colours would be distracting.
  pastel: [
    "#90caf9", "#a5d6a7", "#fff59d", "#ef9a9a", "#80deea",
    "#80cbc4", "#ffcc80", "#ce93d8", "#f48fb1", "#bcaaa4",
    "#b0bec5", "#c5e1a5"
  ],

  // Vivid — high saturation, maximum contrast between series.
  // Bold and attention-grabbing. Suited to presentations and
  // public-facing dashboards.
  vivid: [
    "#e53935", "#8e24aa", "#1e88e5", "#00acc1", "#43a047",
    "#fb8c00", "#f4511e", "#6d4c41", "#00897b", "#3949ab",
    "#c0ca33", "#d81b60"
  ],

  // Monochrome — single blue hue across a range of lightness values.
  // Print-friendly and accessible. Useful when colour meaning must
  // come from the data, not the palette.
  monochrome: [
    "#0d47a1", "#1565c0", "#1976d2", "#1e88e5", "#2196f3",
    "#42a5f5", "#64b5f6", "#90caf9", "#bbdefb", "#e3f2fd",
    "#0a3d91", "#1248a8"
  ],

  // Accessible — Okabe-Ito palette, designed for colour-blind users.
  // Distinguishable across the most common forms of colour vision
  // deficiency (deuteranopia, protanopia, tritanopia).
  // Recommended whenever accessibility is a requirement.
  accessible: [
    "#e69f00", "#56b4e9", "#009e73", "#f0e442", "#0072b2",
    "#d55e00", "#cc79a7", "#000000", "#e69f00", "#56b4e9",
    "#009e73", "#0072b2"
  ],

  // Tableau — inspired by Tableau's classic categorical palette.
  // Widely recognised, carefully tuned for perceptual distinction.
  tableau: [
    "#4e79a7", "#f28e2b", "#e15759", "#76b7b2", "#59a14f",
    "#edc948", "#b07aa1", "#ff9da7", "#9c755f", "#bab0ac",
    "#499894", "#86bcb6"
  ]
}

// Custom palettes override base palettes when names clash.
export default { ...basePalettes, ...customPalettes }
