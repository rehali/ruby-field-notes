// app/javascript/charts/chart_formatters.js
//
// Base formatter registry for ECharts charts.
//
// Usage from Ruby:
//
//   # Axis label formatter — unqualified name
//   y_axis: { type: "value", axisLabel: { formatter: "currency" } }
//
//   # Tooltip formatter — same name, trigger provides context
//   tooltip: { trigger: "axis", formatter: "currency" }
//   tooltip: { trigger: "item", formatter: "percent" }
//
// The resolver in chart_controller.js uses the sibling "trigger" key to
// qualify the lookup automatically:
//
//   trigger: "axis"  →  looks up "axis:currency"
//   trigger: "item"  →  looks up "item:currency"
//   no trigger       →  looks up "currency" (axis label context)
//
// Add application-specific formatters to custom_chart_formatters.js.
// Custom formatters override base formatters when names clash.

import customFormatters from "custom_chart_formatters"

// Parse a value that may arrive as a number or a pre-formatted string ("1,000").
const parse = v => parseFloat(String(v).replace(/,/g, ""))

// Build a right-aligned tooltip table from header and rows array.
// rows: [{ marker, label, value }]
const tooltipTable = (header, rows) => {
  const tableRows = rows.map(({ marker, label, value }) =>
    `<tr>
      <td style="padding-right:16px">${marker}${label}</td>
      <td style="text-align:right"><strong>${value}</strong></td>
    </tr>`
  ).join("")
  return `${header}<br/><table style="width:100%;border-collapse:collapse">${tableRows}</table>`
}

const baseFormatters = {

  // ── Axis label formatters ──────────────────────────────────────────
  // Receive a single value v — used in axisLabel.formatter
  // Referenced by unqualified name: formatter: "currency"

  // Plain integer with thousands separator
  integer:  v => parse(v).toLocaleString(),

  // Percentage — whole number
  percent:  v => `${v}%`,

  // Percentage — one decimal place
  rate:     v => `${parse(v).toFixed(1)}%`,

  // Fixed billions — e.g. "$42B"
  billions: v => `$${parse(v).toLocaleString()}B`,

  // Fixed millions — e.g. "$1,234M"
  millions: v => `$${parse(v).toLocaleString()}M`,

  // Thousands — e.g. "3,842k"
  thousands: v => `${parse(v).toLocaleString()}k`,

  // Auto-scaling currency:
  //   >= 1000  → trillions  "$1.2T"
  //   >= 1     → billions   "$42.3B"
  //   < 1      → millions   "$500M"
  currency: v => {
    const n = parse(v)
    if (n >= 1000) return `$${(n / 1000).toFixed(1)}T`
    if (n >= 1)    return `$${n.toFixed(1)}B`
    return `$${(n * 1000).toFixed(0)}M`
  },


  // ── Axis trigger tooltip formatters ───────────────────────────────
  // Receive params array — all series at the hovered x position.
  // Referenced as: tooltip: { trigger: "axis", formatter: "currency" }
  // Resolved internally as "axis:currency".

  "axis:default": params => {
    const header = params[0]?.axisValueLabel ?? ""
    const rows = params.map(p => ({
      marker: p.marker,
      label:  p.seriesName,
      value:  parse(p.value).toLocaleString()
    }))
    return tooltipTable(header, rows)
  },

  "axis:currency": params => {
    const header = params[0]?.axisValueLabel ?? ""
    const rows = params.map(p => {
      const n = parse(p.value)
      let formatted
      if (n >= 1000)   formatted = `$${(n / 1000).toFixed(1)}T`
      else if (n >= 1) formatted = `$${n.toFixed(1)}B`
      else             formatted = `$${(n * 1000).toFixed(0)}M`
      return { marker: p.marker, label: p.seriesName, value: formatted }
    })
    return tooltipTable(header, rows)
  },

  "axis:billions": params => {
    const header = params[0]?.axisValueLabel ?? ""
    const rows = params.map(p => ({
      marker: p.marker,
      label:  p.seriesName,
      value:  `$${parse(p.value).toLocaleString()}B`
    }))
    return tooltipTable(header, rows)
  },

  "axis:millions": params => {
    const header = params[0]?.axisValueLabel ?? ""
    const rows = params.map(p => ({
      marker: p.marker,
      label:  p.seriesName,
      value:  `$${parse(p.value).toLocaleString()}M`
    }))
    return tooltipTable(header, rows)
  },

  "axis:percent": params => {
    const header = params[0]?.axisValueLabel ?? ""
    const rows = params.map(p => ({
      marker: p.marker,
      label:  p.seriesName,
      value:  `${parse(p.value).toFixed(1)}%`
    }))
    return tooltipTable(header, rows)
  },

  "axis:rate": params => {
    const header = params[0]?.axisValueLabel ?? ""
    const rows = params.map(p => ({
      marker: p.marker,
      label:  p.seriesName,
      value:  `${parse(p.value).toFixed(1)}%`
    }))
    return tooltipTable(header, rows)
  },

  "axis:thousands": params => {
    const header = params[0]?.axisValueLabel ?? ""
    const rows = params.map(p => ({
      marker: p.marker,
      label:  p.seriesName,
      value:  `${parse(p.value).toLocaleString()}k`
    }))
    return tooltipTable(header, rows)
  },

  "axis:integer": params => {
    const header = params[0]?.axisValueLabel ?? ""
    const rows = params.map(p => ({
      marker: p.marker,
      label:  p.seriesName,
      value:  parse(p.value).toLocaleString()
    }))
    return tooltipTable(header, rows)
  },


  // ── Item trigger tooltip formatters ───────────────────────────────
  // Receive a single params object — the specific hovered data point.
  // Referenced as: tooltip: { trigger: "item", formatter: "percent" }
  // Resolved internally as "item:percent".

  "item:default": params =>
    `${params.marker}${params.name}: <strong>${parse(params.value).toLocaleString()}</strong>`,

  "item:percent": params =>
    `${params.marker}${params.name}: <strong>${parse(params.percent).toFixed(1)}%</strong>`,

  "item:currency": params => {
    const n = parse(params.value)
    let formatted
    if (n >= 1000)   formatted = `$${(n / 1000).toFixed(1)}T`
    else if (n >= 1) formatted = `$${n.toFixed(1)}B`
    else             formatted = `$${(n * 1000).toFixed(0)}M`
    return `${params.marker}${params.name}: <strong>${formatted}</strong>`
  },

  "item:billions": params =>
    `${params.marker}${params.name}: <strong>$${parse(params.value).toLocaleString()}B</strong>`,

  "item:thousands": params =>
    `${params.marker}${params.name}: <strong>${parse(params.value).toLocaleString()}k</strong>`,

  "item:rate": params =>
    `${params.marker}${params.name}: <strong>${parse(params.value).toFixed(1)}%</strong>`
}

// Custom formatters override base formatters when names clash.
export default { ...baseFormatters, ...customFormatters }
