// app/javascript/custom_chart_formatters.js
//
// Application-specific chart formatters.
// These are merged on top of the base formatters in chart_formatters.js.
// Custom formatters override base formatters when names clash.
//
// Reference a formatter by name from Ruby:
//
//   tooltip: { trigger: "axis", formatter: "myCustomFormatter" }
//
// Example:
//
// export default {
//   labourForceTooltip: params => {
//     const header = params[0]?.axisValueLabel ?? ""
//     const rows = params.map(p => {
//       const employed    = p.data[0]
//       const unemployed  = p.data[1]
//       const rate        = ((unemployed / (employed + unemployed)) * 100).toFixed(1)
//       return `${p.marker}${p.seriesName}: ${employed.toLocaleString()}k employed (${rate}% UR)`
//     }).join("<br/>")
//     return `${header}<br/>${rows}`
//   }
// }

export default {
  // Module 05 — participation scatter tooltip
  "item:participationScatter": params => {
    const [participation, rate, year] = params.value
    return `${params.marker}${params.seriesName} (${year})<br/>
      Participation: <strong>${participation}%</strong><br/>
      Unemployment: <strong>${rate}%</strong>`
  },

  // Module 07 — calendar heatmap tooltip
  "item:calendarDay": params => {
    const [date, value] = params.value
    const d = new Date(date + "T00:00:00")
    const formatted = d.toLocaleDateString("en-AU", {
      weekday: "short", day: "numeric",
      month:   "long",  year: "numeric"
    })
    return `${formatted}<br/><strong>Activity Index: ${value.toFixed(1)}</strong>`
  },

  // Module 09 — live stocks percentage change tooltip
  "axis:stockChange": params => {
    const header = params[0]?.axisValueLabel ?? ""
    const rows = params.map(p => {
      const val    = parseFloat(p.value)
      const sign   = val >= 0 ? "+" : ""
      const colour = val >= 0 ? "#16a34a" : "#dc2626"
      return `<tr>
        <td style="padding-right:16px">${p.marker}${p.seriesName}</td>
        <td style="text-align:right;color:${colour}">
          <strong>${sign}${val.toFixed(3)}%</strong>
        </td>
      </tr>`
    }).join("")
    return `${header}<br/>
      <table style="width:100%;border-collapse:collapse">${rows}</table>`
  },

  // Module 11 — employment share pie tooltip
  "item:stateSlice": params => {
    const share = params.percent.toFixed(1)
    return `
      <div style="min-width:180px">
        <div style="font-weight:600;margin-bottom:4px">
          ${params.marker}${params.name}
        </div>
        <table style="width:100%;border-collapse:collapse">
          <tr>
            <td style="color:#999;padding-right:12px">Employed</td>
            <td style="text-align:right;font-weight:600">
              ${params.value.toLocaleString()}k
            </td>
          </tr>
          <tr>
            <td style="color:#999;padding-right:12px">Share</td>
            <td style="text-align:right;font-weight:600">${share}%</td>
          </tr>
        </table>
      </div>
    `
  }
}
