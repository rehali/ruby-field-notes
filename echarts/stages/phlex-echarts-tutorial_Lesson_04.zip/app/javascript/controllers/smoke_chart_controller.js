// app/javascript/controllers/smoke_chart_controller.js
import { Controller } from "@hotwired/stimulus"
import * as echarts from "echarts"

export default class extends Controller {
    static values = {
        options: { type: Object, default: {} }
    }

    connect() {
        this.chart = echarts.init(this.element, null, { renderer: "svg" })
        this.chart.setOption(this.optionsValue, { notMerge: true })

        this.resizeObserver = new ResizeObserver(() => this.chart?.resize())
        this.resizeObserver.observe(this.element)
    }

    disconnect() {
        this.resizeObserver?.disconnect()
        this.chart?.dispose()
        this.chart = null
    }
}