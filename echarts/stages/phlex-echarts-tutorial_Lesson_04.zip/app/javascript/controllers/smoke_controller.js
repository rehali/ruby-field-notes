// app/javascript/controllers/smoke_controller.js
import { Controller } from "@hotwired/stimulus"

export default class extends Controller {
    static targets = ["result", "icon"]

    ping() {
        this.resultTarget.textContent = "✓ Stimulus is connected."
        this.iconTarget.textContent = "✓"
        this.element.classList.replace("border-neutral-200", "border-green-200")
        this.element.classList.replace("bg-neutral-50", "bg-green-50")
    }
}