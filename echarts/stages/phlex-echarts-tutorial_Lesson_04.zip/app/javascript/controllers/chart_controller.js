// app/javascript/controllers/chart_controller.js
//
// A self-contained chart runtime for ECharts.
//
// Static usage — just provide options:
//   data-controller="chart"
//   data-chart-options-value="{ ... }"
//
// Real-time usage — add a stream name:
//   data-chart-stream-name-value="live_stocks"
//
// The controller subscribes to the named ActionCable channel automatically.
// The broadcaster sends ECharts options JSON — full or partial.
// Stimulus detects the attribute change and calls setOption.
// No custom JavaScript needed per chart.

import { Controller } from "@hotwired/stimulus"
import * as echarts   from "echarts"
import formatters     from "chart_formatters"
import palettes       from "chart_palettes"
import consumer       from "channels/consumer"

export default class extends Controller {
  static targets = ["mount"]

  static values = {
    options:    { type: Object, default: {} },
    streamName: { type: String, default: "" },
    group:      { type: String, default: "" },
    selectUrl:  { type: String, default: "" }
  }

  connect() {
    this.#initChart()
    if (this.groupValue)      this.#joinGroup()
    if (this.streamNameValue) this.#subscribe()
    if (this.selectUrlValue)  this.#bindClick()
  }

  disconnect() {
    this.subscription?.unsubscribe()
    this.#disposeChart()
  }

  optionsValueChanged(options) {
    if (!this.chart) return
    this.#applyOptions(options)
  }

  // — Private ————————————————————————————————————————————————————————

  #initChart() {
    this.chart = echarts.init(this.mountTarget, null, { renderer: "svg" })
    this.#applyOptions(this.optionsValue)
    this.#startResizeObserver()
  }

  #disposeChart() {
    this.#stopResizeObserver()
    if (this.chart) {
      this.chart.dispose()
      this.chart = null
    }
  }

  #applyOptions(options) {
    this.#resolveOptions(options)
    this.chart.setOption(options, { notMerge: true })
  }

  #startResizeObserver() {
    this.resizeObserver = new ResizeObserver(() => this.chart?.resize())
    this.resizeObserver.observe(this.mountTarget)
  }

  #stopResizeObserver() {
    this.resizeObserver?.disconnect()
    this.resizeObserver = null
  }

  // — Real-time streaming ————————————————————————————————————————————

  #joinGroup() {
    this.chart.group = this.groupValue
    echarts.connect(this.groupValue)
  }

  #bindClick() {
    this.chart.on("click", (params) => {
      const url = new URL(this.selectUrlValue, window.location)
      url.searchParams.set("year", params.name || params.value)
      Turbo.visit(url, { action: "replace" })
    })
  }

  // Subscribes to the named ActionCable channel.
  // The broadcaster sends ECharts options JSON — full or partial update.
  // Setting the data attribute triggers optionsValueChanged automatically.
  #subscribe() {
    this.subscription = consumer.subscriptions.create(
      { channel: "ChartChannel", stream: this.streamNameValue },
      {
        received: (data) => {
          // Merge incoming data with current options
          const current = this.optionsValue
          const updated = { ...current, ...data }
          this.element.dataset.chartOptionsValue = JSON.stringify(updated)
        }
      }
    )
  }

  // — Option resolution ——————————————————————————————————————————————

  #resolveOptions(options) {
    this.#resolvePalette(options)
    this.#resolveFormatters(options)
  }

  #resolvePalette(options) {
    if (typeof options.color === "string" && palettes[options.color]) {
      options.color = palettes[options.color]
    }
  }

  #resolveFormatters(obj) {
    if (typeof obj !== "object" || obj === null) return
    Object.keys(obj).forEach(key => {
      const value = obj[key]
      if (key === "formatter" && typeof value === "string") {
        const trigger   = obj.trigger
        const qualified = trigger ? `${trigger}:${value}` : null
        obj[key] = (qualified && formatters[qualified])
                     ?? formatters[value]
                     ?? value
      } else if (typeof value === "object") {
        this.#resolveFormatters(value)
      }
    })
  }
}
