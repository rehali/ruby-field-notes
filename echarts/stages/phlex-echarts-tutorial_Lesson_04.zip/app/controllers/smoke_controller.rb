# app/controllers/smoke_controller.rb
class SmokeController < ApplicationController
  def index
  end
end