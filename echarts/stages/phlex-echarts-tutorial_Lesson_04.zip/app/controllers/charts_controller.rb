class ChartsController < ApplicationController
  def index
  end

  def gdp_by_industry
    @data = Stats::GdpByIndustry.call(GdpReading.ordered)
  end

  def labour_force
    @data = Stats::LabourForce.call(LabourForceReading.ordered)
  end

  def labour_force_horizontal
    @data = Stats::LabourForce.call(LabourForceReading.ordered)
  end

  def unemployment_rate
    @data = Stats::LabourForce.call(LabourForceReading.ordered)
  end

end