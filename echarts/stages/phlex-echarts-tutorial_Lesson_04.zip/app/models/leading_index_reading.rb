# app/models/leading_index_reading.rb
class LeadingIndexReading < ApplicationRecord
  validates :year, :month, :index_value, presence: true

  scope :ordered,  -> { order(:year, :month) }
  scope :by_year,  ->(y) { where(year: y) }
  scope :recent,   ->(n) { ordered.last(n) }
end