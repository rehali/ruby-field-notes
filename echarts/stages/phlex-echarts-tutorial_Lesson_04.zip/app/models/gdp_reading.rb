# app/models/gdp_reading.rb
class GdpReading < ApplicationRecord
  validates :industry, :year, :quarter, :value_billions, presence: true
  validates :quarter, inclusion: { in: 1..4 }
  validates :industry, uniqueness: { scope: [:year, :quarter] }

  scope :ordered,        -> { order(:industry, :year, :quarter) }
  scope :for_industry,   ->(ind) { where(industry: ind) }
  scope :for_year,       ->(y)   { where(year: y) }
  scope :chronological,  -> { order(:year, :quarter) }

  def self.industries = distinct.pluck(:industry).sort
end