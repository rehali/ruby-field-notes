# Add to db/migrate/20260412000001_create_abs_tables.rb
# (or create a new migration)

# create_table :daily_activity_readings do |t|
#   t.date    :date,  null: false
#   t.decimal :value, null: false, precision: 8, scale: 2
#   t.timestamps
# end
# add_index :daily_activity_readings, :date, unique: true

# app/models/daily_activity_reading.rb
class DailyActivityReading < ApplicationRecord
  validates :date, :value, presence: true
  validates :date, uniqueness: true

  scope :ordered,   -> { order(:date) }
  scope :for_year,  ->(y) { where(date: Date.new(y)..Date.new(y).end_of_year) }
  scope :for_range, ->(from, to) { where(date: from..to) }
end
