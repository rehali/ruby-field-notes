# app/models/cpi_reading.rb
class CpiReading < ApplicationRecord
  validates :category, :year, :quarter, :index_value, presence: true
  validates :quarter, inclusion: { in: 1..4 }
  validates :category, uniqueness: { scope: [:year, :quarter] }

  scope :ordered,        -> { order(:category, :year, :quarter) }
  scope :for_category,   ->(c) { where(category: c) }
  scope :chronological,  -> { order(:year, :quarter) }
  scope :all_groups,     -> { where(category: "All groups CPI") }

  def self.categories = distinct.pluck(:category).sort
end