# app/models/labour_force_reading.rb
class LabourForceReading < ApplicationRecord
  validates :state, :year, :month, presence: true
  validates :month, inclusion: { in: 1..12 }
  validates :state, uniqueness: { scope: [:year, :month] }

  scope :ordered,       -> { order(:state, :year, :month) }
  scope :for_state,     ->(s) { where(state: s) }
  scope :chronological, -> { order(:year, :month) }

  def self.states = distinct.pluck(:state).sort
end