# app/models/national_accounts_reading.rb
class NationalAccountsReading < ApplicationRecord
  validates :indicator, :year, :quarter, :value, presence: true
  validates :quarter, inclusion: { in: 1..4 }
  validates :indicator, uniqueness: { scope: [:year, :quarter] }

  scope :ordered,        -> { order(:indicator, :year, :quarter) }
  scope :for_indicator,  ->(i) { where(indicator: i) }
  scope :chronological,  -> { order(:year, :quarter) }

  # Convenience scopes for common indicators
  scope :gdp,            -> { where(indicator: "Gross domestic product") }
  scope :saving_ratio,   -> { where(indicator: "Household saving ratio") }
  scope :terms_of_trade, -> { where(indicator: "Terms of trade") }

  def self.indicators = distinct.pluck(:indicator).sort
end