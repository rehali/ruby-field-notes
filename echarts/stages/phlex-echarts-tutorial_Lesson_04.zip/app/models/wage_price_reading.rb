# app/models/wage_price_reading.rb
class WagePriceReading < ApplicationRecord
  validates :industry, :year, :quarter, :index_value, presence: true
  validates :quarter, inclusion: { in: 1..4 }
  validates :industry, uniqueness: { scope: [:year, :quarter] }

  scope :ordered,       -> { order(:industry, :year, :quarter) }
  scope :chronological, -> { order(:year, :quarter) }
  scope :all_industries, -> { where(industry: "All Industries") }

  def self.industries = distinct.pluck(:industry).sort
end