# app/models/business_indicator_reading.rb
class BusinessIndicatorReading < ApplicationRecord
  validates :industry, :year, :quarter, :sales_billions, presence: true
  validates :quarter, inclusion: { in: 1..4 }
  validates :industry, uniqueness: { scope: [:year, :quarter] }

  scope :ordered,       -> { order(:industry, :year, :quarter) }
  scope :for_industry,  ->(ind) { where(industry: ind) }
  scope :chronological, -> { order(:year, :quarter) }

  def self.industries = distinct.pluck(:industry).sort
end