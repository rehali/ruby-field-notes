# lib/generators/echarts/install_generator.rb
#
# Installs the Phlex ECharts chart library into a Rails 8 application.
#
# Usage:
#   rails generate echarts:install
#
# What it does:
#   - Copies JavaScript infrastructure files to app/javascript/
#   - Copies Ruby DSL files to app/lib/chart/
#   - Copies Components::Chart base class to app/views/components/
#   - Adds importmap pins
#   - Adds app/lib to autoload paths in config/application.rb
#   - Prints a getting started summary

require "rails/generators"

module Echarts
  class InstallGenerator < Rails::Generators::Base
    source_root File.expand_path("templates", __dir__)

    desc "Installs the Phlex ECharts chart library"

    def install_javascript_files
      say_status :create, "JavaScript infrastructure", :green

      copy_file "javascript/chart_controller.js",
                "app/javascript/controllers/chart_controller.js"

      copy_file "javascript/chart_formatters.js",
                "app/javascript/charts/chart_formatters.js"

      copy_file "javascript/chart_palettes.js",
                "app/javascript/charts/chart_palettes.js"

      copy_file "javascript/custom_chart_formatters.js",
                "app/javascript/charts/custom_chart_formatters.js"

      copy_file "javascript/custom_chart_palettes.js",
                "app/javascript/charts/custom_chart_palettes.js"

      copy_file "javascript/consumer.js",
                "app/javascript/channels/consumer.js"
    end

    def install_ruby_dsl
      say_status :create, "Ruby DSL", :green

      copy_file "lib/chart/options.rb",       "app/lib/chart/options.rb"
      copy_file "lib/chart/series/base.rb",   "app/lib/chart/series/base.rb"
      copy_file "lib/chart/series/line.rb",   "app/lib/chart/series/line.rb"
      copy_file "lib/chart/series/bar.rb",    "app/lib/chart/series/bar.rb"
      copy_file "lib/chart/series/scatter.rb","app/lib/chart/series/scatter.rb"
      copy_file "lib/chart/series/pie.rb",    "app/lib/chart/series/pie.rb"
    end

    def install_base_component
      say_status :create, "Base component", :green

      copy_file "components/chart.rb",
                "app/views/components/chart.rb"
    end

    def add_importmap_pins
      say_status :update, "config/importmap.rb", :green

      pins = <<~RUBY

        # Phlex ECharts chart library
        pin "echarts",                 to: "https://cdn.jsdelivr.net/npm/echarts@5.6.0/dist/echarts.esm.min.js"
        pin "chart_controller",        to: "controllers/chart_controller.js"
        pin "chart_formatters",        to: "charts/chart_formatters.js"
        pin "chart_palettes",          to: "charts/chart_palettes.js"
        pin "custom_chart_formatters", to: "charts/custom_chart_formatters.js"
        pin "custom_chart_palettes",   to: "charts/custom_chart_palettes.js"
        pin "@rails/actioncable",      to: "actioncable.esm.js"
        pin "channels/consumer",       to: "channels/consumer.js"
      RUBY

      append_to_file "config/importmap.rb", pins
    end

    def add_autoload_path
      say_status :update, "config/application.rb", :green

      inject_into_file "config/application.rb",
        after: "class Application < Rails::Application\n" do
        <<~RUBY
            # Autoload chart DSL
            config.autoload_paths << Rails.root.join("app/lib")

        RUBY
      end
    end

    def register_controller
      say_status :update, "app/javascript/controllers/index.js", :green

      inject_into_file "app/javascript/controllers/index.js",
        after: "import { application } from \"./application\"\n" do
        <<~JS
          import ChartController from "chart_controller"
          application.register("chart", ChartController)

        JS
      end
    end

    def print_summary
      say "\n"
      say "=" * 60
      say "  Phlex ECharts installed successfully!", :green
      say "=" * 60
      say "\n"
      say "What was installed:"
      say "  app/javascript/controllers/chart_controller.js"
      say "  app/javascript/charts/chart_formatters.js"
      say "  app/javascript/charts/chart_palettes.js"
      say "  app/javascript/charts/custom_chart_formatters.js"
      say "  app/javascript/charts/custom_chart_palettes.js"
      say "  app/javascript/channels/consumer.js"
      say "  app/lib/chart/options.rb"
      say "  app/lib/chart/series/{base,line,bar,scatter,pie}.rb"
      say "  app/views/components/chart.rb"
      say "\n"
      say "Next steps:"
      say "  1. Restart your Rails server"
      say "  2. Create your first chart component:"
      say "     app/views/components/charts/my_chart.rb"
      say "  3. See the tutorial at:"
      say "     https://github.com/your-org/phlex-echarts-tutorial"
      say "\n"
      say "Formatters:  add to app/javascript/charts/custom_chart_formatters.js"
      say "Palettes:    add to app/javascript/charts/custom_chart_palettes.js"
      say "How it works: see Appendix B and C in the tutorial"
      say "\n"
    end
  end
end
