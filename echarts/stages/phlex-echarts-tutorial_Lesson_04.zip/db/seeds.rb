# db/seeds.rb
#
# Loads ABS data fixtures from db/seeds/data/*.json
#
# Data sourced from the Australian Bureau of Statistics (ABS).
# Licensed under Creative Commons Attribution 4.0 International (CC BY 4.0).
# https://www.abs.gov.au/website-privacy-copyright-and-disclaimer
#
# To regenerate fixtures from the ABS API:
#   ruby db/seeds/fetch_abs_data.rb

require "json"

DATA_DIR = Rails.root.join("db/seeds/data")

def load_fixture(filename)
  path = DATA_DIR.join(filename)
  unless path.exist?
    puts "  MISSING: #{path} — run db/seeds/fetch_abs_data.rb first"
    return []
  end
  JSON.parse(path.read, symbolize_names: true)
end

def seed(model, filename, &block)
  print "Seeding #{model.table_name}... "
  records = load_fixture(filename)
  return puts "skipped (no fixture)" if records.empty?

  model.delete_all
  data = records.map(&block)
  model.insert_all(data)
  puts "#{model.count} records"
end

seed(GdpReading, "gdp_readings.json") do |r|
  {
    industry:       r[:industry],
    year:           r[:year],
    quarter:        r[:quarter],
    value_billions: r[:value_billions],
    created_at:     Time.current,
    updated_at:     Time.current
  }
end

seed(LabourForceReading, "labour_force_readings.json") do |r|
  {
    state:                r[:state],
    year:                 r[:year],
    month:                r[:month],
    employed_thousands:   r[:employed_thousands],
    unemployed_thousands: r[:unemployed_thousands],
    participation_rate:   r[:participation_rate],
    unemployment_rate:    r[:unemployment_rate],
    created_at:           Time.current,
    updated_at:           Time.current
  }
end

seed(CpiReading, "cpi_readings.json") do |r|
  {
    category:    r[:category],
    year:        r[:year],
    quarter:     r[:quarter],
    index_value: r[:index_value],
    created_at:  Time.current,
    updated_at:  Time.current
  }
end

seed(WagePriceReading, "wage_price_readings.json") do |r|
  {
    industry:    r[:industry],
    year:        r[:year],
    quarter:     r[:quarter],
    index_value: r[:index_value],
    created_at:  Time.current,
    updated_at:  Time.current
  }
end

seed(BusinessIndicatorReading, "business_indicator_readings.json") do |r|
  {
    industry:       r[:industry],
    year:           r[:year],
    quarter:        r[:quarter],
    sales_billions: r[:sales_billions],
    created_at:     Time.current,
    updated_at:     Time.current
  }
end

seed(NationalAccountsReading, "national_accounts_readings.json") do |r|
  {
    indicator:  r[:indicator],
    year:       r[:year],
    quarter:    r[:quarter],
    value:      r[:value],
    unit:       r[:unit],
    created_at: Time.current,
    updated_at: Time.current
  }
end

seed(DailyActivityReading, "daily_activity_readings.json") do |r|
  {
    date:       r[:date],
    value:      r[:value],
    created_at: Time.current,
    updated_at: Time.current
  }
end

puts "\nDone."
puts "Attribution: Australian Bureau of Statistics — CC BY 4.0"
