# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# This file is the source Rails uses to define your schema when running `bin/rails
# db:schema:load`. When creating a new database, `bin/rails db:schema:load` tends to
# be faster and is potentially less error prone than running all of your
# migrations from scratch. Old migrations may fail to apply correctly if those
# migrations use external dependencies or application code.
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema[8.1].define(version: 2026_04_12_000001) do
  create_table "business_indicator_readings", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.string "industry", null: false
    t.integer "quarter", null: false
    t.decimal "sales_billions", precision: 10, scale: 3, null: false
    t.datetime "updated_at", null: false
    t.integer "year", null: false
    t.index ["industry", "year", "quarter"], name: "idx_on_industry_year_quarter_e5a7b2b0f0", unique: true
    t.index ["industry"], name: "index_business_indicator_readings_on_industry"
  end

  create_table "cpi_readings", force: :cascade do |t|
    t.string "category", null: false
    t.datetime "created_at", null: false
    t.decimal "index_value", precision: 8, scale: 2, null: false
    t.integer "quarter", null: false
    t.datetime "updated_at", null: false
    t.integer "year", null: false
    t.index ["category", "year", "quarter"], name: "index_cpi_readings_on_category_and_year_and_quarter", unique: true
  end

  create_table "daily_activity_readings", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.date "date", null: false
    t.datetime "updated_at", null: false
    t.decimal "value", precision: 8, scale: 2, null: false
    t.index ["date"], name: "index_daily_activity_readings_on_date", unique: true
  end

  create_table "gdp_readings", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.string "industry", null: false
    t.integer "quarter", null: false
    t.datetime "updated_at", null: false
    t.decimal "value_billions", precision: 10, scale: 3, null: false
    t.integer "year", null: false
    t.index ["industry", "year", "quarter"], name: "index_gdp_readings_on_industry_and_year_and_quarter", unique: true
    t.index ["year"], name: "index_gdp_readings_on_year"
  end

  create_table "labour_force_readings", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.decimal "employed_thousands", precision: 8, scale: 1
    t.integer "month", null: false
    t.decimal "participation_rate", precision: 5, scale: 1
    t.string "state", null: false
    t.decimal "unemployed_thousands", precision: 7, scale: 1
    t.decimal "unemployment_rate", precision: 5, scale: 1
    t.datetime "updated_at", null: false
    t.integer "year", null: false
    t.index ["state", "year", "month"], name: "index_labour_force_readings_on_state_and_year_and_month", unique: true
    t.index ["state"], name: "index_labour_force_readings_on_state"
  end

  create_table "national_accounts_readings", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.string "indicator", null: false
    t.integer "quarter", null: false
    t.string "unit"
    t.datetime "updated_at", null: false
    t.decimal "value", precision: 12, scale: 3, null: false
    t.integer "year", null: false
    t.index ["indicator", "year", "quarter"], name: "idx_on_indicator_year_quarter_93d79a82c6", unique: true
    t.index ["indicator"], name: "index_national_accounts_readings_on_indicator"
  end

  create_table "wage_price_readings", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.decimal "index_value", precision: 8, scale: 2, null: false
    t.string "industry", null: false
    t.integer "quarter", null: false
    t.datetime "updated_at", null: false
    t.integer "year", null: false
    t.index ["industry", "year", "quarter"], name: "index_wage_price_readings_on_industry_and_year_and_quarter", unique: true
  end
end
