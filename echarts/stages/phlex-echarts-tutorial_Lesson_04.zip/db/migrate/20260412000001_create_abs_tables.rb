# db/migrate/20260412000001_create_abs_tables.rb
class CreateAbsTables < ActiveRecord::Migration[8.1]
  def change
    # GDP by Industry (ANA_IND_GVA)
    # 19 industries, quarterly, 2000-2024
    create_table :gdp_readings do |t|
      t.string  :industry,       null: false
      t.integer :year,           null: false
      t.integer :quarter,        null: false
      t.decimal :value_billions, null: false, precision: 10, scale: 3
      t.timestamps
    end
    add_index :gdp_readings, [:industry, :year, :quarter], unique: true
    add_index :gdp_readings, :year

    # Labour Force by State (LF)
    # 8 states, monthly, 2012-2024
    create_table :labour_force_readings do |t|
      t.string  :state,               null: false
      t.integer :year,                null: false
      t.integer :month,               null: false
      t.decimal :employed_thousands,  precision: 8, scale: 1
      t.decimal :unemployed_thousands,precision: 7, scale: 1
      t.decimal :participation_rate,  precision: 5, scale: 1
      t.decimal :unemployment_rate,   precision: 5, scale: 1
      t.timestamps
    end
    add_index :labour_force_readings, [:state, :year, :month], unique: true
    add_index :labour_force_readings, :state

    # CPI — All Groups (CPI)
    # Single aggregate series, quarterly, 2000-2024
    create_table :cpi_readings do |t|
      t.string  :category,    null: false
      t.integer :year,        null: false
      t.integer :quarter,     null: false
      t.decimal :index_value, null: false, precision: 8, scale: 2
      t.timestamps
    end
    add_index :cpi_readings, [:category, :year, :quarter], unique: true

    # Wage Price Index — All Industries (WPI)
    # Single aggregate series, quarterly, 2000-2024
    create_table :wage_price_readings do |t|
      t.string  :industry,    null: false
      t.integer :year,        null: false
      t.integer :quarter,     null: false
      t.decimal :index_value, null: false, precision: 8, scale: 2
      t.timestamps
    end
    add_index :wage_price_readings, [:industry, :year, :quarter], unique: true

    # Business Indicators by Industry (QBIS)
    # Multiple industries, quarterly, 2005-2024
    create_table :business_indicator_readings do |t|
      t.string  :industry,       null: false
      t.integer :year,           null: false
      t.integer :quarter,        null: false
      t.decimal :sales_billions, null: false, precision: 10, scale: 3
      t.timestamps
    end
    add_index :business_indicator_readings, [:industry, :year, :quarter], unique: true
    add_index :business_indicator_readings, :industry

    # National Accounts Aggregates (ANA_AGG)
    # Multiple indicators (GDP, saving ratio etc), quarterly, 2000-2024
    create_table :national_accounts_readings do |t|
      t.string  :indicator, null: false
      t.integer :year,      null: false
      t.integer :quarter,   null: false
      t.decimal :value,     null: false, precision: 12, scale: 3
      t.string  :unit
      t.timestamps
    end
    add_index :national_accounts_readings, [:indicator, :year, :quarter], unique: true
    add_index :national_accounts_readings, :indicator

    create_table :daily_activity_readings do |t|
      t.date    :date,  null: false
      t.decimal :value, null: false, precision: 8, scale: 2
      t.timestamps
    end
    add_index :daily_activity_readings, :date, unique: true
  end
end