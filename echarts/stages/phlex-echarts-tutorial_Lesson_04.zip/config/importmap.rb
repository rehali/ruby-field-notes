# Pin npm packages by running ./bin/importmap

pin "application"
pin "@hotwired/turbo-rails", to: "turbo.min.js"
pin "@hotwired/stimulus", to: "stimulus.min.js"
pin "@hotwired/stimulus-loading", to: "stimulus-loading.js"
pin_all_from "app/javascript/controllers", under: "controllers"
pin "echarts" # @6.0.0
pin "tslib" # @2.3.0
pin "zrender/lib/", to: "zrender--lib--.js" # @6.0.0

# Phlex ECharts chart library
pin "echarts",                 to: "https://cdn.jsdelivr.net/npm/echarts@5.6.0/dist/echarts.esm.min.js"
pin "chart_controller",        to: "controllers/chart_controller.js"
pin "chart_formatters",        to: "charts/chart_formatters.js"
pin "chart_palettes",          to: "charts/chart_palettes.js"
pin "custom_chart_formatters", to: "charts/custom_chart_formatters.js"
pin "custom_chart_palettes",   to: "charts/custom_chart_palettes.js"
pin "@rails/actioncable",      to: "actioncable.esm.js"
pin "channels/consumer",       to: "channels/consumer.js"
