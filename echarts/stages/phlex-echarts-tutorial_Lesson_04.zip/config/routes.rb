# config/routes.rb
Rails.application.routes.draw do
  get "smoke", to: "smoke#index", as: :smoke
  get "up" => "rails/health#show", as: :rails_health_check
  root "charts#index"

  get "charts/index", to: "charts#index", as: :charts
  get "charts/gdp_by_industry",         to: "charts#gdp_by_industry"
  get "charts/labour_force",            to: "charts#labour_force"
  get "charts/labour_force_horizontal", to: "charts#labour_force_horizontal"
  get "charts/unemployment_rate",       to: "charts#unemployment_rate"

end