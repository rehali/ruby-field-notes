# config/routes.rb
Rails.application.routes.draw do
  get "smoke", to: "smoke#index", as: :smoke
  get "up" => "rails/health#show", as: :rails_health_check
  root "smoke#index"

  scope :charts do
    get "/",        to: "charts#index",    as: :charts
    # get "gdp", to: "charts#gdp", as: :charts_gdp
    # get "gdp_area", to: "charts#gdp_area", as: :charts_gdp_area
    # get "formatter_currency", to: "charts#formatter_currency", as: :charts_formatter_currency
    # get "formatter_percent", to: "charts#formatter_percent", as: :charts_formatter_percent
    # get "formatter_units", to: "charts#formatter_units", as: :charts_formatter_units
    # get "palette_demo", to: "charts#palette_demo", as: :charts_palette_demo
    # get "labour_force", to: "charts#labour_force", as: :charts_labour_force
    # get "labour_force_horizontal", to: "charts#labour_force_horizontal", as: :charts_labour_force_horizontal
    # get "unemployment_rate", to: "charts#unemployment_rate", as: :charts_unemployment_rate
    # get "labour_market_analysis", to: "charts#labour_market_analysis", as: :charts_labour_market_analysis
    # get "single_year_calendar", to: "charts#single_year_calendar", as: :charts_single_year_calendar
    # get "multi_year_calendar", to: "charts#multi_year_calendar", as: :charts_multi_year_calendar
    # get "national_accounts_gauges", to: "charts#national_accounts_gauges", as: :charts_national_accounts_gauges
    # get "live_stocks", to: "charts#live_stocks", as: :charts_live_stocks
    # get "label_formatting", to: "charts#label_formatting", as: :charts_label_formatting
    # get "labour_dashboard", to: "charts#labour_dashboard", as: :charts_labour_dashboard
    # get "wages_vs_inflation", to: "charts#wages_vs_inflation", as: :charts_wages_vs_inflation
    # get "labour_force_map", to: "charts#labour_force_map", as: :charts_labour_force_map
  end
end