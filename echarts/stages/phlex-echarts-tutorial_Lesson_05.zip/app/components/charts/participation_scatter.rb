# app/views/components/charts/participation_scatter.rb
module Components
  module Charts
    class ParticipationScatter < Components::Chart
      prop :data, _Any, default: -> { {} }

      private

      def chart_options
        ::Chart::Options.new(
          color:     "tableau",
          toolbox:   { feature: { saveAsImage: {}, restore: {} } },
          tooltip:   { trigger: "item", formatter: "participationScatter" },
          legend:    { type: "scroll", bottom: 5 },
          visualMap: {
            show:      false,
            dimension: 2,
            min:       2012,
            max:       2024,
            inRange:   { colorLightness: [0.35, 0.85] }
          },
          x_axis: {
            type:         "value",
            min:          "dataMin",
            name:         "Participation Rate (%)",
            nameLocation: "middle",
            nameGap:      30,
            axisLabel:    { formatter: "rate" }
          },
          y_axis: {
            type:         "value",
            min:          "dataMin",
            name:         "Unemployment Rate (%)",
            nameLocation: "middle",
            nameGap:      40,
            axisLabel:    { formatter: "rate" }
          },
          grid:   { bottom: 60, left: 16, right: 16, containLabel: true },
          series: build_series
        )
      end

      def build_series
        @data.map do |state, rows|
          ::Chart::Series::Scatter.new(
            name: state,
            data: rows.map { |r| [r[:participation], r[:rate], r[:year]] }
          )
        end
      end
    end
  end
end