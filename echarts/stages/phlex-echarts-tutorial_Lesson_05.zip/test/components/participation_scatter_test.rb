# test/components/participation_scatter_test.rb
require "test_helper"

class ParticipationScatterTest < ActiveSupport::TestCase
  def sample_data
    {
      "New South Wales" => [
        { year: 2022, employed: 4100.0, rate: 3.8,
          participation: 63.2, unemployed: 158.0 }
      ],
      "Victoria" => [
        { year: 2022, employed: 3400.0, rate: 4.1,
          participation: 65.1, unemployed: 140.0 }
      ]
    }
  end

  test "produces one series per state" do
    component = Components::Charts::ParticipationScatter.new(data: sample_data)
    options   = component.send(:chart_options).to_h

    assert_equal 2, options[:series].size
    assert_equal "scatter", options[:series].first[:type]
  end

  test "each data point is [participation, rate, year]" do
    component = Components::Charts::ParticipationScatter.new(data: sample_data)
    options   = component.send(:chart_options).to_h
    nsw       = options[:series].find { |s| s[:name] == "New South Wales" }

    point = nsw[:data].first
    assert_equal 3,    point.size
    assert_equal 2022, point[2]
  end

  test "includes visualMap on dimension 2" do
    component = Components::Charts::ParticipationScatter.new(data: sample_data)
    options   = component.send(:chart_options).to_h

    assert options[:visualMap].present?
    assert_equal 2, options[:visualMap][:dimension]
  end
end