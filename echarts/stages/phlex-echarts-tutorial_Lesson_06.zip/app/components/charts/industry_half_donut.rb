# app/views/components/charts/industry_half_donut.rb
module Components
  module Charts
    class IndustryHalfDonut < Components::Chart
      prop :data, _Any, default: -> { [] }

      private

      def chart_options
        ::Chart::Options.new(
          color:   "vivid",
          toolbox: { feature: { saveAsImage: {} } },
          tooltip: { trigger: "item", formatter: "industrySlice" },
          legend:  { type: "scroll", bottom: 0 },
          series: [
            ::Chart::Series::Pie.new(
              name:       "Industry Sales",
              data:       series_data,
              radius:     ["45%", "72%"],
              center:     ["50%", "72%"],
              startAngle: 180,
              endAngle:   360,
              label:      { position: "outside", formatter: "{b}\n{d}%" }
            )
          ]
        )
      end

      def series_data
        top6  = @data.first(6)
        other = @data[6..]

        return top6.map { |r| { name: r[:industry], value: r[:sales] } } if other.empty?

        other_sales = other.sum { |r| r[:sales] }.round(1)
        (top6 + [{ industry: "Other", sales: other_sales }])
          .map { |r| { name: r[:industry], value: r[:sales] } }
      end
    end
  end
end