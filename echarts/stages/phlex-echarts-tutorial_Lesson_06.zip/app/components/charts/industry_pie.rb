# app/views/components/charts/industry_pie.rb
module Components
  module Charts
    class IndustryPie < Components::Chart
      prop :data, _Any, default: -> { [] }

      private

      def chart_options
        ::Chart::Options.new(
          color:   "vivid",
          toolbox: { feature: { saveAsImage: {} } },
          tooltip: { trigger: "item", formatter: "industrySlice" },
          legend:  { type: "scroll", bottom: 5 },
          series: [
            ::Chart::Series::Pie.new(
              name:   "Industry Sales",
              data:   series_data,
              radius: "65%",
              center: ["50%", "45%"],
              label:  { formatter: "{b}\n{d}%" }
            )
          ]
        )
      end

      def series_data
        @data.map { |r| { name: r[:industry], value: r[:sales] } }
      end
    end
  end
end