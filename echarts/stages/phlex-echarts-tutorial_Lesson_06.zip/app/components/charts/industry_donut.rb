# app/views/components/charts/industry_donut.rb
module Components
  module Charts
    class IndustryDonut < Components::Chart
      prop :data, _Any, default: -> { [] }

      private

      def chart_options
        total = @data.sum { |r| r[:sales] }.round(1)

        ::Chart::Options.new(
          color:   "vivid",
          toolbox: { feature: { saveAsImage: {} } },
          tooltip: { trigger: "item", formatter: "industrySlice" },
          legend:  { type: "scroll", bottom: 5 },
          graphic: [
            {
              type:  "text",
              left:  "center",
              top:   "middle",
              style: {
                text:       "$#{total}B\nTotal Sales",
                textAlign:  "center",
                fontSize:   14,
                fontWeight: "bold",
                lineHeight: 20
              }
            }
          ],
          series: [
            ::Chart::Series::Pie.new(
              name:     "Industry Sales",
              data:     series_data,
              radius:   ["40%", "68%"],
              center:   ["50%", "45%"],
              label:    { show: false },
              emphasis: {
                label: { show: true, fontSize: 13, fontWeight: "bold" }
              }
            )
          ]
        )
      end

      def series_data
        @data.map { |r| { name: r[:industry], value: r[:sales] } }
      end
    end
  end
end