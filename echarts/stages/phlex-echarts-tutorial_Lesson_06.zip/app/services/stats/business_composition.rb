# app/services/stats/business_composition.rb
module Stats
  module BusinessComposition
    extend self

    # Returns industries for the latest quarter, sorted by sales descending:
    # [
    #   { industry: "Mining",       sales: 142.3, share: 18.4 },
    #   { industry: "Construction", sales: 98.7,  share: 12.6 },
    #   ...
    # ]
    def call
      latest_year    = BusinessIndicatorReading.maximum(:year)
      latest_quarter = BusinessIndicatorReading
                         .where(year: latest_year)
                         .maximum(:quarter)

      readings = BusinessIndicatorReading
                   .where(year: latest_year, quarter: latest_quarter)
                   .where.not(industry: "Total")
                   .where("sales_billions > 0")
                   .order(sales_billions: :desc)

      total = readings.sum(:sales_billions).to_f

      readings.map do |r|
        {
          industry: r.industry,
          sales:    r.sales_billions.to_f.round(1),
          share:    ((r.sales_billions.to_f / total) * 100).round(1)
        }
      end
    end
  end
end