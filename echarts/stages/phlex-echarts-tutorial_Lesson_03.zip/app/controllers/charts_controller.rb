class ChartsController < ApplicationController
  def index
  end

  def gdp_by_industry
    @data = Stats::GdpByIndustry.call(GdpReading.ordered)
  end

end