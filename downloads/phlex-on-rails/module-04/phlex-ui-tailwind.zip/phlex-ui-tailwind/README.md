# Phlex::UI — Tailwind v4 Components

This package contains the `Phlex::UI` component library from Module 3,
restyled with Tailwind CSS v4 utility classes for use in a Rails 8 app.

## Installation

1. Copy `app/components/` into your Rails app's `app/components/` directory
2. Copy `test/components/` into your Rails app's `test/components/` directory
3. Copy `test/component_test_helper.rb` into your Rails app's `test/` directory
4. Run the tests to confirm everything is working:

```bash
bin/rails test test/components/
```

## Components included

| Component | File | Description |
|-----------|------|-------------|
| `Button` | `button.rb` | Primary, secondary, danger, ghost variants |
| `Badge` | `badge.rb` | Inline label with colour variants |
| `Avatar` | `avatar.rb` | User avatar with initials fallback |
| `Alert` | `alert.rb` | Info, success, warning, danger messages |
| `Card` | `card.rb` | Container with header, body, footer slots |
| `Table` | `table.rb` | Column-based data table |
| `Panel` | `panel.rb` | Simple titled container |
| `Link` | `link.rb` | Default, secondary, button variants |
| `Heading` | `heading.rb` | h1–h6 with consistent type scale |
| `EmptyState` | `empty_state.rb` | Empty state with optional CTA |

## Notes

- `base.rb` is provided for reference. Your existing `Components::Base`
  should already have `Literal::Properties` and `class_names` — merge
  any differences rather than replacing outright.
- All components use Tailwind v4 utility classes. No `tailwind.config.js`
  is required — Tailwind v4 scans Ruby files automatically.
- The `dismissible` button in `Alert` is structural only. Wire it to a
  Stimulus controller in Module 8.
