# frozen_string_literal: true

require "test_helper"
require "nokogiri"

module ComponentTestHelper
  def render_component(component)
    component.call(view_context: view_context)
  end

  def render_fragment(component)
    Nokogiri::HTML5.fragment(render_component(component))
  end

  def view_context
    controller = ApplicationController.new
    controller.request = ActionDispatch::TestRequest.create
    controller.view_context
  end
end
