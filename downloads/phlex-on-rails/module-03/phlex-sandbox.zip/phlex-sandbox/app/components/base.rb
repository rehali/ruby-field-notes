require "phlex"
require "date"
require "literal"

module Components
  extend Phlex::Kit

  class Base < Phlex::HTML
    extend Literal::Properties

    private

    # Merge multiple class strings, filtering out nils and blanks
    def class_names(*classes)
      classes.flatten.compact.reject(&:empty?).join(" ")
    end
  end
end