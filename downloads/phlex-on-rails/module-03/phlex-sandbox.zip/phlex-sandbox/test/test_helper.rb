# test/test_helper.rb
require "minitest/autorun"
require "nokogiri"

Dir[File.join(__dir__, "../app/components/**/*.rb")].each { |f| require f }

module ComponentTestHelper
  def render(component)
    component.call
  end

  def render_fragment(component)
    Nokogiri::HTML5.fragment(render(component))
  end
end