# test/components/button_test.rb
require_relative "../test_helper"

class ButtonTest < Minitest::Test
  include ComponentTestHelper

  def test_renders_label
    html = render Components::Button.new(label: "Save")
    assert_includes html, ">Save<"
  end

  def test_default_variant_has_no_class
    doc = render_fragment Components::Button.new(label: "Save")
    assert_nil doc.at_css("button")["class"],
               "Primary button should have no class attribute"
  end

  def test_secondary_variant_has_class
    doc = render_fragment Components::Button.new(label: "Save",
                                                 variant: :secondary)
    assert_equal "secondary", doc.at_css("button")["class"]
  end

  def test_disabled_has_attribute
    doc = render_fragment Components::Button.new(label: "Save", disabled: true)
    assert doc.at_css("button[disabled]"), "Expected disabled attribute"
  end

  def test_wrong_type_raises
    assert_raises(Literal::TypeError) { Components::Button.new(label: 42) }
  end
end