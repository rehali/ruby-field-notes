# test/components/alert_test.rb
require_relative "../test_helper"

class AlertTest < Minitest::Test
  include ComponentTestHelper
  def test_has_role_alert
    doc = render_fragment Components::Alert.new(message: "Hello")
    assert doc.at_css("[role=alert]"), "Expected role=alert"
  end
  def test_dismissible_shows_button
    doc = render_fragment Components::Alert.new(
      message: "Hello", dismissible: true
    )
    assert doc.at_css("button"), "Expected dismiss button"
  end
  def test_not_dismissible_hides_button
    doc = render_fragment Components::Alert.new(message: "Hello")
    assert_nil doc.at_css("button"), "Expected no dismiss button"
  end
  def test_success_variant_class
    doc = render_fragment Components::Alert.new(
      message: "OK", variant: :success
    )
    assert_includes doc.at_css("[role=alert]")["class"], "success"
  end
  def test_danger_variant_class
    doc = render_fragment Components::Alert.new(
      message: "Error", variant: :danger
    )
    assert_includes doc.at_css("[role=alert]")["class"], "danger"
  end
end
