# test/components/card_test.rb
require_relative "../test_helper"

class CardTest < Minitest::Test
  include ComponentTestHelper

  def test_renders_article_element
    doc = render_fragment Components::Card.new
    assert doc.at_css("article"), "Expected an article element"
  end

  def test_no_header_when_not_provided
    doc = render_fragment Components::Card.new
    assert_equal "", doc.at_css(".card-header").text.strip
  end

  def test_no_body_when_not_provided
    doc = render_fragment Components::Card.new
    assert_equal "", doc.at_css(".card-body").text.strip
  end

  def test_no_footer_when_not_provided
    doc = render_fragment Components::Card.new
    assert_equal "", doc.at_css(".card-footer").text.strip
  end

  def test_header_slot_renders
    html = Components::Card.new.call do |card|
      card.header { "Header content" }
    end
    doc = Nokogiri::HTML5.fragment(html)
    assert_includes doc.at_css(".card-header").text, "Header content"
  end

  def test_body_slot_renders
    html = Components::Card.new.call do |card|
      card.body { "Body content" }
    end
    doc = Nokogiri::HTML5.fragment(html)
    assert_includes doc.at_css(".card-body").text, "Body content"
  end

  def test_footer_slot_renders
    html = Components::Card.new.call do |card|
      card.footer { "Footer content" }
    end
    doc = Nokogiri::HTML5.fragment(html)
    assert_includes doc.at_css(".card-footer").text, "Footer content"
  end

  def test_all_slots_render_together
    html = Components::Card.new.call do |card|
      card.header { "My header" }
      card.body   { "My body"   }
      card.footer { "My footer" }
    end
    doc = Nokogiri::HTML5.fragment(html)
    assert_includes doc.at_css(".card-header").text, "My header"
    assert_includes doc.at_css(".card-body").text,   "My body"
    assert_includes doc.at_css(".card-footer").text,  "My footer"
  end

end