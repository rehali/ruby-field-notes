# demo.rb
require_relative "app/components/base"
require_relative "app/components/heading"
require_relative "app/components/button"
require_relative "app/components/badge"
require_relative "app/components/avatar"
require_relative 'app/components/link'
require_relative 'app/components/panel'
require_relative 'app/components/card'
require_relative 'app/components/section'
require_relative "app/components/table"
require_relative "app/components/alert"

class DemoPage < Phlex::HTML
  include Components

  def view_template
    doctype
    html(lang: "en") do
      head do
        meta(charset: "utf-8")
        meta(name: "viewport", content: "width=device-width, initial-scale=1")
        title { "Phlex::UI Demo" }
        link(
          rel: "stylesheet",
          href: "https://cdn.jsdelivr.net/npm/@picocss/pico@2/css/pico.min.css"
        )
        style { raw safe(File.read(File.join(__dir__, "demo.css"))) }
      end
      body do
        main(class: "container") do
          show_note
          show_headings
          show_buttons
          show_badges
          show_avatars
          show_links
          show_panels
          show_cards
          show_sections
          show_tables
          show_alerts
        end
      end
    end
  end

  private

  def show_note
    blockquote do
      p { strong { "Why Pico CSS?" } }
      p do
        plain "This demo uses Pico CSS rather than Tailwind. Module 3 is "
        plain "about component structure — props, slots, and composition. "
        plain "Pico gives us clean output with zero configuration so the "
        plain "component code stays readable. Tailwind is introduced "
        plain "properly in Module 4 inside a real Rails app."
      end
    end
  end

  def show_headings
    section_header("Headings")
    Heading(text: "Heading level 1", level: 1)
    Heading(text: "Heading level 2", level: 2)
    Heading(text: "Heading level 3", level: 3)
  end

  def show_buttons
    section_header("Buttons")
    div(class: "demo-row") do
      Button(label: "Primary", variant: :primary)
      Button(label: "Secondary", variant: :secondary)
      Button(label: "Danger", variant: :danger)
      Button(label: "Ghost", variant: :ghost)
      Button(label: "Disabled", disabled: true)
    end
  end

  def show_badges
    section_header("Badges")
    div(class: "demo-row") do
      [:default, :primary, :success, :warning, :danger].each do |v|
        Badge(label: v.to_s.capitalize, variant: v)
      end
    end
  end

  def show_avatars
    section_header("Avatars")
    div(class: "demo-row") do
      Avatar(name: "Alice Smith", size: :sm)
      Avatar(name: "Bob Jones")
      Avatar(name: "Carol White", size: :lg)
      Avatar(name: "Alice Smith",
             image_url: "https://i.pravatar.cc/150?u=alice")
    end
  end

  def show_links
    section_header("Links")
    div(class: "demo-row") do
      Link(label: "Default link", href: "#")
      Link(label: "Secondary link", href: "#", variant: :secondary)
      Link(label: "Button link", href: "#", variant: :button)
    end
  end

  require_relative "app/components/panel"

  def show_panels
    section_header("Panels")
    div(class: "demo-grid-3") do
      Panel(title: "Fruits") do
        ul do
          %w[Apple Banana Cherry].each { |f| li { f } }
        end
      end

      Panel(title: "About Phlex") do
        p { "Phlex is a Ruby gem for building HTML components." }
      end

      Panel(title: "Status") do
        div(class: "demo-row") do
          Badge(label: "Active", variant: :success)
          Badge(label: "Pending", variant: :warning)
          Badge(label: "Archived", variant: :default)
        end
      end
    end

    Panel(title: "Actions") do
      p { "Ready to proceed" }
      Button(label: "Continue", variant: :primary)
    end
  end

  def show_cards
    section_header("Cards")
    div(class: "demo-grid-2") do
      Card() do |card|
        card.header { h3 { "Full card" } }
        card.body { p { "With header, body, and footer slots." } }
        card.footer { Button(label: "Action", variant: :secondary) }
      end
    end
  end

  def show_sections
    section_header("Sections")
    Section(title: "Featured content") do |s|
      s.body { p { "This is the main body area." } }
      s.aside { p { "This is the sidebar area." } }
    end
  end

  def section_header(title)
    hr
    h2 { title }
  end

  DEMO_PEOPLE = [
    { name: "Alice", role: "Admin" },
    { name: "Bob", role: "Member" },
    { name: "Carol", role: "Member" },
  ]

  COMPONENTS_LIST = [
    { name: "Button", status: "Done" },
    { name: "Badge", status: "Done" },
    { name: "Avatar", status: "Done" },
    { name: "Card", status: "Done" },
    { name: "Table", status: "Done" },
  ]

  def show_tables
    section_header("Tables")

    Table(rows: DEMO_PEOPLE, caption: "Team members") do |t|
      t.column("Name") { |row| row[:name] }
      t.column("Role") { |row| row[:role] }
    end

    Table(rows: COMPONENTS_LIST, caption: "Phlex::UI components") do |t|
      t.column("Component") { |row| row[:name] }
      t.column("Status") { |row| Badge(label: row[:status], variant: :success) }
    end
  end

  def show_alerts
    section_header("Alerts")
    Alert(message: "This is an info message.",  variant: :info)
    Alert(message: "Operation successful.",      variant: :success)
    Alert(message: "Please review your input.", variant: :warning)
    Alert(message: "Something went wrong.",      variant: :danger,
          dismissible: true)
  end

end

File.write("demo.html", DemoPage.new.call)
system("open demo.html")
puts "Demo written to demo.html"