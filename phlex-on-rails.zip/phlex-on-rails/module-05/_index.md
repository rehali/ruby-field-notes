---
linkTitle: Module 05 - Component Library
weight: 50
---

## Module 5 — UI Component Library

> **8 lessons · Components · Phlex::UI + KanbanFlow**  
> We install Lookbook as our component browser, expand `Phlex::UI` with
> new components KanbanFlow needs, and build the first real views of the
> app — the boards index and show pages.

---

## Before we start

In Module 4 we installed the `Phlex::UI` component library from the
downloadable zip. Those components work, but we haven't had a way to
browse or preview them in isolation. In this module we fix that
immediately with Lookbook — then put the components to work in real views.

By the end of this module KanbanFlow has a working boards index with
proper empty state handling, a board show placeholder, and a component
browser at `/lookbook` that documents the entire `Phlex::UI` library.
