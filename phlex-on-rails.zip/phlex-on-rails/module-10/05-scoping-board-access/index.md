---
linkTitle: Scoping board access
description: "Rails 8 authentication with Plex-rails"
weight: 50
---

## Lesson 5 — Scoping board access

Flash messages render as dismissible `Alert` components between the
nav and the main content. They disappear on the next navigation or
when dismissed.

### Updating the boards index

The boards index currently shows all boards. Scope the heading and
empty state to the signed-in user:

```ruby
# app/views/boards/index.rb
class Views::Boards::Index < Views::Base
  def page_title = "Your Boards"

  def initialize(boards:)
    @boards = boards
  end

  def view_template
    div(class: "flex items-center justify-between mb-6") do
      h1(class: "text-2xl font-bold text-text") { "Your Boards" }
      Button(label: "+ New Board", href: new_board_path)
    end

    if @boards.empty?
      EmptyState(
        title:        "No boards yet",
        message:      "Create your first board to get started.",
        action_label: "Create a board",
        action_url:   new_board_path
      )
    else
      div(class: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4") do
        @boards.each { |board| render_board_card(board) }
      end
    end
  end

  private

  def render_board_card(board)
    a(href: board_path(board),
      class: "block p-6 bg-surface rounded-lg border border-border " \
             "hover:shadow-md transition-shadow") do
      h2(class: "font-semibold text-text mb-1") { board.name }
      p(class: "text-sm text-text-muted") do
        plain "#{board.columns.count} columns"
      end
    end
  end
end
```

### Verify the full auth flow

Test each path in order:

1. Visit `/` — should redirect to `/session/new`
2. Sign up at `/registration/new` — should land on boards index
3. Sign out — should redirect to sign in
4. Sign in — should land on boards index
5. Request password reset — should redirect to sign in with notice
6. Create a board — should appear in index, scoped to current user
7. Open a second browser, sign in as a different user — should see
   only their own boards

---

## Module 10 summary

- Rails 8's `authentication` generator produces readable, ownable code
  — `has_secure_password`, a `Session` model, an `Authentication`
  concern, and password reset via `generates_token_for`
- Auth views are Phlex — `Sessions::New`, `Passwords::New`,
  `Passwords::Edit`, and `Registrations::New` all use the existing
  `TextInput` and `Button` components
- A minimal layout in `Views::Base#render_minimal_layout` gives auth
  pages a clean, focused screen without the app nav
- `current_user` in components is provided by `def current_user = helpers.current_user` in `Components::Base`
- `owned_boards` scopes board creation and lookup to the current user
- `add_owner_as_member` callback ensures every board creator has an
  admin membership record
- Card and column controllers verify board ownership via a
  `verify_board_access` before_action
- Flash messages render as dismissible `Alert` components in
  `AppLayout`

### What's deferred

Board membership, invitations, and role-based access control are
covered in the companion **Rails 8 Authentication deep-dive** tutorial.
That tutorial picks up where this module leaves off — adding shared
boards, invitation emails, and a `BoardPolicy` for fine-grained
access control.

### Views built this module

- `Views::Sessions::New`
- `Views::Passwords::New`
- `Views::Passwords::Edit`
- `Views::Registrations::New`

### KanbanFlow progress

KanbanFlow is now a real multi-user application. Users have their own
accounts, their own boards, and can't see each other's data. The
`current_user` stub is gone. Authentication protects every page. The
app is ready for the finishing touches in Module 11.

---

## Up next

[[11-finishing-touches|Module 11 — Finishing touches]] — error pages,
empty states, accessibility audit, deployment preparation, and a
review of everything KanbanFlow has become.

---

*Tags: `#phlex` `#rails` `#authentication` `#multiuser` `#kanbanflow`
`#tutorial`*