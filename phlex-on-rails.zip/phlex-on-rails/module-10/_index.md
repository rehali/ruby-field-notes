---
linkTitle: Module 10 - Authentication
weight: 100
---

## Module 10 — Authentication and Multi-user

> **5 lessons · Auth · KanbanFlow**  
> We add Rails 8's built-in authentication, replace the generated ERB
> views with Phlex, wire `current_user` into the component system, and
> scope the app so users only see their own boards.

---

## Before we start

KanbanFlow has had a `current_user` stub since Module 9 —
`User.first`, always returning the same user. The app works, but
everyone shares the same account. This module fixes that.

We use Rails 8's built-in authentication generator — not Devise. The
generator produces readable, ownable Ruby code directly in your app.
You can read every line, change anything, and understand exactly what's
happening. For a tutorial series, that matters.

The scope is deliberately focused: sign up, sign in, sign out, password
reset, and scoping the app to the current user. Board membership,
invitations, and role-based access control are substantial topics that
deserve their own deep-dive — those are covered in a companion tutorial.


