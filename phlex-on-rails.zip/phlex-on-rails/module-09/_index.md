---
linkTitle: Module 09 - Hotwire
weight: 90
---

## Module 9 — Hotwire: Morph, Frames, and Streams

> **6 lessons · Real-time · KanbanFlow**  
> We replace the board view placeholder with a fully interactive Kanban
> board. Turbo Morph does the heavy lifting — Frames and Streams appear
> only where they solve a problem morphing can't.

---

## Before we start

Module 8 gave KanbanFlow a complete set of interactive UI components.
This module wires them into a real board view — columns, cards, inline
creation, drag-and-drop ordering, and real-time multi-user updates.

The approach follows the Hotwire mental model as it stands in 2024,
after Turbo 8 changed what "default" means. We'll establish that mental
model in Lesson 1 before writing any code.
