---
linkTitle: Module 08 - Stimulus and components
weight: 80
---

# Module 8 — Stimulus and Components

> **8 lessons · Behaviour · Phlex::UI + KanbanFlow**  
> We go deep on Stimulus and add six interactive components to
> `Phlex::UI` — Modal, Dropdown, Toast, Accordion, Tabs, and properly
> wired dismissible Alerts. A final lesson covers cross-controller
> communication patterns.

---

## Before we start

Module 7 ended with a theme toggle — our first Stimulus controller.
We built it as a working feature but didn't dig into how Stimulus and
Phlex work together as a general pattern. That's the job of Module 8.

Every interactive component we build follows the same pattern:

1. A Phlex component that generates the correct `data-*` attributes
2. A Stimulus controller that handles the behaviour
3. A Lookbook preview that demonstrates every state

By the end of this module `Phlex::UI` has a complete set of interactive
primitives. Module 9 applies them to KanbanFlow's board view.
