---
linkTitle: Module 11 - Membership, Policy and Presence
weight: 110
---

## Module 11 — Membership, Policy and Presence

> **5 lessons · Multi-user · KanbanFlow**  
> We wire up real board membership, implement a plain Ruby access policy,
> build a members management page, make UI elements role-aware, and add
> a presence bar showing who's currently viewing the board.

---

## Before we start

Module 10 gave KanbanFlow real authentication. Users can sign up, sign
in, and sign out. But every board is still restricted to its owner —
the multi-user architecture we've built (memberships, broadcasting,
presence) has no fuel yet.

This module fixes that. By the end, boards can be shared between users,
access is controlled by role, and members can see who else is viewing
the board in real time.

Two design decisions up front:

**Owner vs admin** — "admin" in the code means the board owner. There
is exactly one admin per board — the user who created it. Everyone else
is a member. The owner can do everything; members can do most things.

**Card deletion** — any member can delete any card for now. In a
production app you'd restrict this to the card creator or admins by
adding a `created_by_id` to cards and checking it in the policy. We
note this as a known simplification and leave it for the reader to
extend.

