---
linkTitle: Setup and seeding
weight: 10
---

## Lesson 1 — Setup and seeding

### Update the `Membership` model

The `memberships` table already has a `role` integer column but the
model doesn't define the enum. Add it:

```ruby
# app/models/membership.rb
class Membership < ApplicationRecord
  belongs_to :user
  belongs_to :board

  enum :role, { member: 0, admin: 1 }, default: :member
end
```

This gives us `membership.admin?`, `membership.member?`,
`Membership.admins`, `Membership.members`, and the `role:` symbol
interface throughout.

### Update seeds

The existing seeds file has two problems: users have no password so
they can't sign in, and Alice gets a duplicate admin membership because
`Board.create!` already triggers `add_owner_as_member`.

Replace `db/seeds.rb`:

```ruby
# db/seeds.rb
alice = User.create!(name: "Alice Smith",  email: "alice@example.com", password: "password")
bob   = User.create!(name: "Bob Walker",   email: "bob@example.com",   password: "password")
carol = User.create!(name: "Carol Harris", email: "carol@example.com", password: "password")


# Board.create! triggers add_owner_as_member — Alice gets admin
# membership automatically. Do not add it again manually.
board = Board.create!(name: "KanbanFlow Development", user: alice)

# Add Bob and Carol as members
Membership.create!(user: bob,   board: board, role: :member)
Membership.create!(user: carol, board: board, role: :member)

todo  = board.columns.create!(name: "To Do",       position: 0)
doing = board.columns.create!(name: "In Progress", position: 1)
done  = board.columns.create!(name: "Done",        position: 2)

todo.cards.create!(title: "Set up Rails app",        position: 0)
todo.cards.create!(title: "Install Phlex",           position: 1)
todo.cards.create!(title: "Build component library", position: 2)

doing.cards.create!(title: "Build AppLayout", position: 0)
done.cards.create!(title: "Create Rails app", position: 0)
```

Reset and reseed:

```bash
bin/rails db:seed:replant
```

`db:seed:replant` truncates all tables and re-seeds without
re-running migrations. You now have three users — sign in as any of
them with the password `password`.

### Verify membership

```bash
bin/rails runner "puts Board.first.memberships.map { |m| \"#{m.user.name}: #{m.role}\" }"
# Alice: admin
# Bob: member
# Carol: member
```

### Update `BoardsController` to use membership scope

Currently `BoardsController#index` shows `owned_boards`. Update it to
show all boards the user is a member of — which now includes shared
boards:

```ruby
def index
  render Views::Boards::Index.new(boards: current_user.boards)
end
```

`current_user.boards` uses `has_many :boards, through: :memberships` —
it returns all boards where a membership record exists, including boards
the user owns (since `add_owner_as_member` creates that record).
