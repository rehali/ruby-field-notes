---
title: "Module 01 — Introduction to Phlex"
weight: 10
---

> **2 lessons · some background**  
> The problem with erb.  
> The phlex component philosophy.

The first module is a general discussion on the strengths and weaknesses of the __`_partial`__ approach to both building reusable components and also breaking down complex pages into smaller, more understandable parts.

We then look at what __Phlex__ brings to the table in being able to overcome the limitations of pure __`ERB`__. 

It is worthwhile noting that __Phlex__ is completely compatible with your existing __Rails__ apps and you can choose just to migrate small parts of your app. A good place to start would be with some of those trickier __`_partials`__.
