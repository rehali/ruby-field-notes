---
title: "Phlex on Rails"
description: "Building with Phlex v2, Rails 8, Tailwind CSS, Stimulus, and Importmaps"
weight: 11
cascade:
  type: docs
---
