---
linkTitle: Module 04 - Rails Integration
weight: 40
---

# Module 04 — Rails Integration

> **7 lessons · Rails + tools · KanbanFlow v0.1**  
> Phlex meets Rails 8. We install, configure, and make our first architectural decisions — then wire up the KanbanFlow skeleton and see `Phlex::UI` rendered properly in a browser for the first time.


## Before we start

This module is a significant moment in the series. Everything built in Module 3 — the component library, the patterns, the tests — now moves into a real Rails app. For the first time you will see your `Phlex::UI` components rendered with proper Tailwind styling in a browser.

Two things to do before Lesson 1:

**Create the Rails app:**

```bash
rails new kanban_flow --css tailwind --javascript importmap
cd kanban_flow
```

**Port `Phlex::UI` from the sandbox:**

Copy `app/components/` from `phlex-sandbox` into the new Rails app. The component files are already self-contained — they will work in Rails without modification, though we will update their Tailwind classes during Lesson 6.