# lib/panels/preview_panel.rb
#
# WebView-based preview panel — replaces the HtmlWindow version from Module 4.
#
# The public interface is identical to the Module 4 version:
#   preview_panel.update(html)
#   preview_panel.clear
#
# The frame code is completely unchanged — only this file is different.
# That is the point of the lesson: swap the implementation, keep the interface.

require 'base64'
require_relative '../js_bridge'
require_relative '../html/preview_page'

class PreviewPanel < Wx::Panel
  def initialize(parent)
    super(parent)
    @ready = false
    build_ui
    load_page
  end

  # Update the preview with rendered HTML.
  # Called by the frame on every debounced keypress — same as Module 4.
  def update(html)
    return unless @ready
    @bridge.call('updateContent', { html: html })
  end

  def clear
    return unless @ready
    @bridge.call('updateContent', { html: '' })
  end

  private

  def build_ui
    label = Wx::StaticText.new(self, label: 'Preview')
    font  = label.font
    font.weight = Wx::FONTWEIGHT_BOLD
    label.font  = font

    @webview = Wx::WEB::WebView.new(self, Wx::ID_ANY, 'about:blank')

    sizer = Wx::VBoxSizer.new
    sizer.add(label,    0, Wx::ALL, 6)
    sizer.add(@webview, 1, Wx::EXPAND | Wx::LEFT | Wx::RIGHT | Wx::BOTTOM, 4)
    set_sizer(sizer)
  end

  def load_page
    @bridge = JsBridge.new(@webview)

    encoded = Base64.strict_encode64(PreviewPage.html)
    @webview.load_url("data:text/html;base64,#{encoded}")

    @webview.evt_webview_loaded(@webview.id) do
      next if @webview.current_url == 'about:blank'
      @webview.add_script_message_handler('bridge')
      @bridge.run_script("RubyBridge.emit('ready', {})")
    end

    @webview.evt_webview_script_message_received(@webview.id) do |event|
      @bridge.dispatch(event.get_string)
    end

    @bridge.on('ready') do
      @ready = true
    end
  end
end
