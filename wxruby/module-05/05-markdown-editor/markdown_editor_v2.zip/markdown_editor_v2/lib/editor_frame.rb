# lib/editor_frame.rb
#
# Identical to the Module 4 editor_frame.rb except for require paths.
# The frame has no knowledge of whether the preview uses HtmlWindow
# or WebView — it just calls preview_panel.update(html).
#
# This is the point of good separation of concerns: swap the
# implementation in preview_panel.rb, the frame is untouched.

require_relative 'panels/editor_panel'
require_relative 'panels/preview_panel'
require_relative 'models/markdown_document'

class EditorFrame < Wx::Frame
  PREVIEW_DELAY_MS = 300

  def initialize
    super(nil, title: 'Markdown Editor', size: [1200, 750])

    @document = MarkdownDocument.new
    @loading  = false
    @preview_timer = Wx::Timer.new(self)

    build_menu
    build_ui
    bind_events

    update_title
    load_sample_content
    layout
    centre
  end

  private

  def build_menu
    menu_bar  = Wx::MenuBar.new
    file_menu = Wx::Menu.new
    file_menu.append(Wx::ID_NEW,    "&New\tCtrl+N")
    file_menu.append(Wx::ID_OPEN,   "&Open...\tCtrl+O")
    file_menu.append(Wx::ID_SAVE,   "&Save\tCtrl+S")
    file_menu.append(Wx::ID_SAVEAS, "Save &As...\tCtrl+Shift+S")
    file_menu.append_separator
    @export_id = file_menu.append(Wx::ID_ANY, "&Export HTML...\tCtrl+E").id
    file_menu.append_separator
    file_menu.append(Wx::ID_EXIT,   "E&xit\tCtrl+Q")
    menu_bar.append(file_menu, "&File")
    set_menu_bar(menu_bar)
  end

  def build_ui
    @panel   = Wx::Panel.new(self)
    splitter = Wx::SplitterWindow.new(@panel,
                 style: Wx::SP_3DSASH | Wx::SP_LIVE_UPDATE)

    @preview = PreviewPanel.new(splitter)
    @editor  = EditorPanel.new(splitter, on_change: method(:on_text_changed))

    splitter.split_vertically(@editor, @preview, 560)
    splitter.set_minimum_pane_size(200)

    create_status_bar
    set_status_text('Ready')

    sizer = Wx::VBoxSizer.new
    sizer.add(splitter, 1, Wx::EXPAND | Wx::ALL, 4)
    @panel.set_sizer(sizer)
    @panel.layout
  end

  def bind_events
    evt_close              { |event| on_close(event) }
    evt_menu(Wx::ID_NEW)   { on_new }
    evt_menu(Wx::ID_OPEN)  { on_open }
    evt_menu(Wx::ID_SAVE)  { on_save }
    evt_menu(Wx::ID_SAVEAS){ on_save_as }
    evt_menu(@export_id)   { on_export }
    evt_menu(Wx::ID_EXIT)  { close }
    evt_timer(@preview_timer.id) { update_preview }
  end

  def on_text_changed
    return if @loading
    @document.update_content(@editor.content)
    update_title
    @preview_timer.start(PREVIEW_DELAY_MS, Wx::TIMER_ONE_SHOT)
  end

  def update_preview
    @preview.update(@document.to_html)
    set_status_text('Preview updated')
  end

  def on_close(event)
    if @document.modified && !confirm_discard
      # do not close
    else
      event.skip
    end
  end

  def on_new
    return unless confirm_discard
    @loading = true
    @editor.clear
    @loading = false
    @document.reset
    @preview.clear
    update_title
    set_status_text('New document')
  end

  def on_open
    return unless confirm_discard
    dialog = Wx::FileDialog.new(
      self, 'Open file', '', '',
      'Markdown files (*.md;*.markdown)|*.md;*.markdown|All files (*.*)|*.*',
      Wx::FD_OPEN | Wx::FD_FILE_MUST_EXIST
    )
    if dialog.show_modal == Wx::ID_OK
      load_file(dialog.path)
    end
    dialog.destroy
  end

  def on_save
    if @document.path
      save_file(@document.path)
    else
      on_save_as
    end
  end

  def on_save_as
    dialog = Wx::FileDialog.new(
      self, 'Save file',
      @document.path ? File.dirname(@document.path) : '',
      @document.path ? File.basename(@document.path) : 'untitled.md',
      'Markdown files (*.md)|*.md|All files (*.*)|*.*',
      Wx::FD_SAVE | Wx::FD_OVERWRITE_PROMPT
    )
    if dialog.show_modal == Wx::ID_OK
      save_file(dialog.path)
    end
    dialog.destroy
  end

  def on_export
    dialog = Wx::FileDialog.new(
      self, 'Export HTML',
      @document.path ? File.dirname(@document.path) : '',
      @document.path ? File.basename(@document.path, '.*') + '.html' : 'untitled.html',
      'HTML files (*.html)|*.html',
      Wx::FD_SAVE | Wx::FD_OVERWRITE_PROMPT
    )
    if dialog.show_modal == Wx::ID_OK
      File.write(dialog.path, @document.to_full_html, encoding: 'utf-8')
      set_status_text("Exported: #{File.basename(dialog.path)}")
    end
    dialog.destroy
  end

  def load_file(path)
    @loading = true
    @document.load(path)
    @editor.content = @document.content
    @loading = false
    update_title
    update_preview
    set_status_text("Opened: #{File.basename(path)}")
  rescue => e
    Wx::message_box("Could not open file:\n#{e.message}", 'Error',
                    Wx::OK | Wx::ICON_ERROR)
  end

  def save_file(path)
    @document.update_content(@editor.content)
    @document.save_as(path)
    update_title
    set_status_text("Saved: #{File.basename(path)}")
  rescue => e
    Wx::message_box("Could not save file:\n#{e.message}", 'Error',
                    Wx::OK | Wx::ICON_ERROR)
  end

  def confirm_discard
    return true unless @document.modified
    result = Wx::message_box(
      'You have unsaved changes. Discard them?',
      'Unsaved changes',
      Wx::YES_NO | Wx::ICON_QUESTION
    )
    result == Wx::YES
  end

  def update_title
    self.title = "#{@document.title} — Markdown Editor"
  end

  def load_sample_content
    sample = <<~MARKDOWN
      # Markdown Editor — WebView Preview

      This editor uses a **WebView** for the preview — a full browser engine
      replacing the `HtmlWindow` from Module 4.

      ## What improved

      | Feature            | HtmlWindow | WebView  |
      |--------------------|------------|----------|
      | CSS stylesheets    | Limited    | ✓ Full   |
      | Syntax highlighting| ✗          | ✓        |
      | Table styling      | Basic      | ✓ Custom |
      | Blockquote styling | Basic      | ✓ Custom |
      | Typography control | Limited    | ✓ Full   |
      | JavaScript         | ✗          | ✓        |

      ## Syntax highlighting

      Ruby code blocks are highlighted by highlight.js — loaded from CDN:

      ```ruby
      class MarkdownDocument
        def to_html
          Kramdown::Document.new(@content, input: 'GFM').to_html
        end
      end
      ```

      JavaScript too:

      ```javascript
      RubyBridge.register('updateContent', function(payload) {
        document.getElementById('content').innerHTML = payload.html;
        document.querySelectorAll('pre code').forEach(function(block) {
          hljs.highlightElement(block);
        });
        return { ok: true };
      });
      ```

      ## What didn't change

      The `MarkdownDocument` model and `EditorPanel` are **identical** to
      Module 4. The frame is identical. Only `PreviewPanel` changed —
      and its public interface (`update(html)`, `clear`) stayed the same.

      > Swap the implementation, keep the interface.
      > That is the value of good separation of concerns.

      ---

      Try editing this document — the preview updates as you type.
    MARKDOWN

    @loading = true
    @document.update_content(sample)
    @editor.content = sample
    @loading = false
    # Preview updates after ready fires — handled by the debounce timer
    @preview_timer.start(PREVIEW_DELAY_MS, Wx::TIMER_ONE_SHOT)
  end
end
