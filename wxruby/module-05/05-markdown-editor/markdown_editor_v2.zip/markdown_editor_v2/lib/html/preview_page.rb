# lib/html/preview_page.rb
#
# The WebView preview page.
# Renders markdown HTML with:
#   - Full CSS styling (impossible with HtmlWindow)
#   - Syntax highlighting via highlight.js (impossible with HtmlWindow)
#   - Proper code block formatting
#   - Responsive typography
#
# The page exposes one JS method Ruby can call: updateContent(html)
# Ruby calls this whenever the markdown changes.

require 'base64'

module PreviewPage
  JS_CLIENT = Base64.strict_encode64(
    File.read(File.join(__dir__, '../../assets/js/js_bridge_client.js'))
  )

  def self.html
    <<~HTML
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">

        <!-- js_bridge_client.js -->
        <script src="data:text/javascript;base64,#{JS_CLIENT}"></script>

        <!-- highlight.js for syntax highlighting — impossible with HtmlWindow -->
        <link rel="stylesheet"
              href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/github.min.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js"></script>

        <style>
          /* Full CSS support — impossible with HtmlWindow */
          * { box-sizing: border-box; }

          body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            font-size: 15px;
            line-height: 1.7;
            color: #24292e;
            background: #ffffff;
            padding: 32px 40px;
            max-width: 860px;
            margin: 0 auto;
          }

          h1, h2, h3, h4, h5, h6 {
            font-weight: 600;
            line-height: 1.25;
            margin-top: 24px;
            margin-bottom: 12px;
            color: #1a1a2e;
          }
          h1 { font-size: 2em;   border-bottom: 2px solid #e1e4e8; padding-bottom: 8px; }
          h2 { font-size: 1.5em; border-bottom: 1px solid #e1e4e8; padding-bottom: 6px; }
          h3 { font-size: 1.25em; }

          p { margin: 0 0 16px; }

          a { color: #0366d6; text-decoration: none; }
          a:hover { text-decoration: underline; }

          /* Inline code */
          code {
            font-family: 'SFMono-Regular', Consolas, monospace;
            font-size: 0.875em;
            background: #f6f8fa;
            border: 1px solid #e1e4e8;
            border-radius: 3px;
            padding: 2px 5px;
            color: #e36209;
          }

          /* Code blocks — styled by highlight.js + our overrides */
          pre {
            background: #f6f8fa;
            border: 1px solid #e1e4e8;
            border-radius: 6px;
            padding: 16px;
            overflow-x: auto;
            margin: 0 0 16px;
          }
          pre code {
            background: none;
            border: none;
            padding: 0;
            color: inherit;
            font-size: 0.875em;
          }

          /* Tables */
          table {
            border-collapse: collapse;
            width: 100%;
            margin: 0 0 16px;
          }
          th, td {
            border: 1px solid #e1e4e8;
            padding: 8px 12px;
            text-align: left;
          }
          th { background: #f6f8fa; font-weight: 600; }
          tr:nth-child(even) { background: #f9f9f9; }

          /* Blockquotes */
          blockquote {
            border-left: 4px solid #0366d6;
            margin: 0 0 16px;
            padding: 8px 16px;
            color: #6a737d;
            background: #f1f8ff;
            border-radius: 0 4px 4px 0;
          }
          blockquote p { margin: 0; }

          /* Lists */
          ul, ol { padding-left: 24px; margin: 0 0 16px; }
          li { margin-bottom: 4px; }

          /* Horizontal rule */
          hr {
            border: none;
            border-top: 2px solid #e1e4e8;
            margin: 24px 0;
          }

          /* Images */
          img { max-width: 100%; border-radius: 4px; }

          /* Empty state */
          .empty {
            color: #6a737d;
            font-style: italic;
            margin-top: 40px;
            text-align: center;
          }
        </style>
      </head>
      <body>
        <div id="content">
          <p class="empty">Start typing in the editor to see the preview...</p>
        </div>
        <script>
          // Ruby calls this method to update the preview content
          RubyBridge.register('updateContent', function(payload) {
            document.getElementById('content').innerHTML = payload.html;

            // Apply syntax highlighting to all code blocks
            document.querySelectorAll('pre code').forEach(function(block) {
              hljs.highlightElement(block);
            });

            return { ok: true };
          });
        </script>
      </body>
      </html>
    HTML
  end
end
