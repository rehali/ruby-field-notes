# lib/models/markdown_document.rb
#
# Represents a markdown document — content, file path, and dirty state.
# Converts markdown to HTML via kramdown with GFM support.
# No UI knowledge — pure Ruby model following the pattern from lesson 3.2.

require 'kramdown'
require 'kramdown-parser-gfm'

class MarkdownDocument
  attr_reader :path, :content, :modified

  def initialize
    reset
  end

  def reset
    @path     = nil
    @content  = ''
    @modified = false
  end

  def load(path)
    @content  = File.read(path, encoding: 'utf-8')
    @path     = path
    @modified = false
  end

  def save
    raise 'No path set' unless @path
    File.write(@path, @content, encoding: 'utf-8')
    @modified = false
  end

  def save_as(path)
    @path = path
    save
  end

  def update_content(text)
    return if text == @content
    @content  = text
    @modified = true
  end

  # Convert current markdown content to HTML.
  # Uses kramdown with the GFM (GitHub Flavoured Markdown) parser
  # for full support of fenced code blocks, tables, and strikethrough.
  def to_html
    Kramdown::Document.new(@content, input: 'GFM').to_html
  end

  # Wrap the converted HTML in a minimal document with basic styling.
  # HtmlWindow doesn't support CSS stylesheets, but inline font and
  # colour attributes work for basic presentation improvements.
  def to_full_html
    body = to_html
    <<~HTML
      <html>
      <body>
        #{body}
      </body>
      </html>
    HTML
  end

  def title
    name = @path ? File.basename(@path) : 'Untitled'
    @modified ? "#{name} *" : name
  end
end
