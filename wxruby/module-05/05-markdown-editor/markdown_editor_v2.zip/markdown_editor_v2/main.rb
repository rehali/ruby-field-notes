# main.rb
#
# Module 5, Lesson 5.5 — Project: Markdown editor with WebView
# wxRuby3 Desktop Development Tutorial Series
#
# The Module 4 markdown editor upgraded from HtmlWindow to WebView.
# The model and editor panel are unchanged. Only the preview panel
# changes — and the improvement is immediately visible.
#
# Requires internet for highlight.js CDN (syntax highlighting).
# Run with: bundle exec ruby main.rb

require 'wx'
require_relative 'lib/editor_frame'

Wx::App.run { EditorFrame.new.show }
