# main.rb
#
# Lesson 5.3 — Live data with Chart.js
# wxRuby3 Desktop Development Tutorial Series
#
# A sensor dashboard feeding live data from Ruby into Chart.js
# charts via JsBridge. Three simulated sensors update every 500ms.
# The wx sidebar shows stats and controls.
#
# Run with: ruby main.rb
# Requires internet access for Chart.js CDN.

require 'wx'
require_relative 'lib/dashboard_frame'

Wx::App.run do
  Wx::Timer.every(25) { Thread.pass }
  DashboardFrame.new.show
end
