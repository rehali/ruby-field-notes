# lib/html/dashboard_page.rb
#
# The dashboard HTML page as a Ruby module.
# Keeping HTML here keeps the frame clean.
# Chart.js is loaded from CDN — requires internet access.
# js_bridge_client.js is injected as a base64 data URI by the frame.

require 'base64'

module DashboardPage
  JS_CLIENT = Base64.strict_encode64(
    File.read(File.join(__dir__, '../../assets/js/js_bridge_client.js'))
  )

  def self.html(series_config)
    # Build JS config from Ruby sensor data
    series_js = series_config.map do |name, config|
      "{ name: '#{name}', colour: '#{config[:colour]}', unit: '#{config[:unit]}' }"
    end.join(",\n      ")

    <<~HTML
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <!-- js_bridge_client.js — the JS side of the JsBridge library -->
        <script src="data:text/javascript;base64,#{JS_CLIENT}"></script>
        <!-- Chart.js from CDN -->
        <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
        <style>
          * { box-sizing: border-box; margin: 0; padding: 0; }
          body {
            background: #1e1e2e;
            color: #cdd6f4;
            font-family: -apple-system, sans-serif;
            padding: 16px;
          }
          h2 {
            font-size: 11px;
            color: #89b4fa;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            margin-bottom: 6px;
          }
          .grid {
            display: grid;
            grid-template-columns: repeat(#{series_config.length}, 1fr);
            gap: 12px;
          }
          .card {
            background: #313244;
            border-radius: 8px;
            padding: 12px;
          }
          .value {
            font-size: 22px;
            font-weight: bold;
            margin-bottom: 8px;
          }
          canvas { width: 100% !important; height: 120px !important; }
        </style>
      </head>
      <body>
        <div class="grid" id="grid"></div>
        <script>
          var MAX_POINTS = 60;
          var charts = {};
          var latest = {};

          var seriesConfig = [
            #{series_js}
          ];

          // Build a card and chart for each series
          seriesConfig.forEach(function(s) {
            var card = document.createElement('div');
            card.className = 'card';
            card.id = 'card-' + s.name;

            var heading = document.createElement('h2');
            heading.textContent = s.name + ' (' + s.unit + ')';

            var valueEl = document.createElement('div');
            valueEl.className = 'value';
            valueEl.id = 'value-' + s.name;
            valueEl.textContent = '—';

            var canvas = document.createElement('canvas');
            canvas.id = 'chart-' + s.name;

            card.appendChild(heading);
            card.appendChild(valueEl);
            card.appendChild(canvas);
            document.getElementById('grid').appendChild(card);

            var ctx = canvas.getContext('2d');
            charts[s.name] = new Chart(ctx, {
              type: 'line',
              data: {
                labels: [],
                datasets: [{
                  data: [],
                  borderColor: s.colour,
                  backgroundColor: s.colour + '22',
                  borderWidth: 2,
                  pointRadius: 0,
                  fill: true,
                  tension: 0.3
                }]
              },
              options: {
                animation: false,
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                  x: { display: false },
                  y: {
                    ticks: { color: '#cdd6f4', font: { size: 9 } },
                    grid:  { color: '#45475a' }
                  }
                }
              }
            });
          });

          // ── Methods Ruby can call ───────────────────────────────────────

          // Push a new data point onto a chart
          RubyBridge.register('pushDataPoint', function(p) {
            var chart = charts[p.series];
            if (!chart) return { ok: false, error: 'Unknown series: ' + p.series };

            chart.data.labels.push(p.label);
            chart.data.datasets[0].data.push(p.value);

            if (chart.data.labels.length > MAX_POINTS) {
              chart.data.labels.shift();
              chart.data.datasets[0].data.shift();
            }

            // 'none' skips animation for smooth live updates
            chart.update('none');

            latest[p.series] = p.value;
            document.getElementById('value-' + p.series).textContent =
              p.value;

            return { ok: true };
          });

          // Return current stats for a series
          RubyBridge.register('getStats', function(p) {
            var chart = charts[p.series];
            if (!chart) return { error: 'Unknown series' };

            var data = chart.data.datasets[0].data;
            if (data.length === 0) return { min: null, max: null, mean: null, count: 0 };

            var sum = data.reduce(function(a, b) { return a + b; }, 0);
            return {
              min:   Math.min.apply(null, data),
              max:   Math.max.apply(null, data),
              mean:  Math.round(sum / data.length * 10) / 10,
              count: data.length
            };
          });

          // Clear all data from a series
          RubyBridge.register('clearSeries', function(p) {
            var chart = charts[p.series];
            if (!chart) return { ok: false };
            chart.data.labels = [];
            chart.data.datasets[0].data = [];
            chart.update('none');
            latest[p.series] = null;
            document.getElementById('value-' + p.series).textContent = '—';
            return { ok: true };
          });
        </script>
      </body>
      </html>
    HTML
  end
end
