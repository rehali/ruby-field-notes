# lib/dashboard_frame.rb
#
# Main frame — coordinates ChartPanel and StatsPanel.
# Manages the data timer and routes data between model and view.
# Thin coordinator following the lesson 3.2 pattern.

require 'base64'
require_relative 'models/sensor'
require_relative 'panels/chart_panel'
require_relative 'panels/stats_panel'

class DashboardFrame < Wx::Frame
  DATA_INTERVAL_MS = 500   # new data point every 500ms

  def initialize
    super(nil, title: 'Live Sensor Dashboard', size: [1000, 560])

    @sensor     = Sensor.new
    @data_timer = nil

    build_ui
    bind_events

    layout
    centre
  end

  private

  def build_ui
    @panel = Wx::Panel.new(self)

    splitter = Wx::SplitterWindow.new(@panel,
                 style: Wx::SP_3DSASH | Wx::SP_LIVE_UPDATE)

    @chart_panel = ChartPanel.new(splitter, on_ready: method(:on_chart_ready))
    @stats_panel = StatsPanel.new(splitter,
                     on_refresh: method(:on_refresh_stats),
                     on_clear:   method(:on_clear_all))

    splitter.split_vertically(@chart_panel, @stats_panel, 720)
    splitter.set_minimum_pane_size(200)

    create_status_bar
    set_status_text('Loading dashboard...')

    sizer = Wx::VBoxSizer.new
    sizer.add(splitter, 1, Wx::EXPAND | Wx::ALL, 4)
    @panel.set_sizer(sizer)
    @panel.layout
  end

  def bind_events
    evt_close { |event| on_close(event) }
  end

  # ── Chart ready ────────────────────────────────────────────────────────────

  def on_chart_ready
    set_status_text('Dashboard ready — live data starting')
    start_data_timer
  end

  # ── Data feed ──────────────────────────────────────────────────────────────

  def start_data_timer
    @data_timer = Wx::Timer.new(self)
    evt_timer(@data_timer.id) { on_tick }
    @data_timer.start(DATA_INTERVAL_MS)
  end

  def on_tick
    label = Time.now.strftime('%H:%M:%S')
    @sensor.series_names.each do |series|
      value = @sensor.read(series)
      @chart_panel.push_data(series, value, label)
    end
  end

  # ── Stats ──────────────────────────────────────────────────────────────────

  def on_refresh_stats
    @sensor.series_names.each do |series|
      @chart_panel.get_stats(series) do |stats, error|
        next if error
        @stats_panel.update_stats(series, stats)
      end
    end
    @stats_panel.set_status("Stats refreshed at #{Time.now.strftime('%H:%M:%S')}")
    set_status_text('Stats refreshed')
  end

  # ── Clear ──────────────────────────────────────────────────────────────────

  def on_clear_all
    @sensor.series_names.each do |series|
      @chart_panel.clear_series(series)
    end
    set_status_text('All series cleared')
  end

  def on_close(event)
    @data_timer&.stop
    event.skip
  end
end
