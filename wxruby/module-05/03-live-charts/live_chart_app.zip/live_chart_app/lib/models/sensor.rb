# lib/models/sensor.rb
#
# Simulates sensor readings with realistic drift.
# Pure Ruby — no UI knowledge.

class Sensor
  SERIES = {
    'temperature' => { baseline: 22.0, drift: 0.3, unit: '°C',  colour: '#f38ba8' },
    'humidity'    => { baseline: 55.0, drift: 0.5, unit: '%',   colour: '#89b4fa' },
    'pressure'    => { baseline: 1013.0, drift: 0.2, unit: 'hPa', colour: '#a6e3a1' },
  }.freeze

  def initialize
    @state = {}
  end

  def read(series)
    config = SERIES[series] || return
    @state[series] ||= config[:baseline]
    @state[series]  += (rand - 0.5) * config[:drift] * 2
    @state[series].round(1)
  end

  def unit(series)
    SERIES.dig(series, :unit) || ''
  end

  def colour(series)
    SERIES.dig(series, :colour) || '#ffffff'
  end

  def series_names
    SERIES.keys
  end
end
