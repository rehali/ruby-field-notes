# lib/panels/stats_panel.rb

class StatsPanel < Wx::Panel
  def initialize(parent, on_refresh: nil, on_clear: nil)
    super(parent)
    @on_refresh  = on_refresh
    @on_clear    = on_clear
    @stat_labels = {}
    build_ui
  end

  def update_stats(series, stats)
    label = @stat_labels[series]
    return unless label
    if stats['count'].to_i == 0
      label.label = 'No data'
    else
      label.label = "min: #{stats['min']}  max: #{stats['max']}  mean: #{stats['mean']}"
    end
    layout
  end

  def set_status(text)
    @status.label = text
    layout
  end

  private

  def build_ui
    outer = Wx::VBoxSizer.new

    Sensor::SERIES.each do |series, config|
      box   = Wx::StaticBox.new(self, label: "#{series.capitalize} (#{config[:unit]})")
      label = Wx::StaticText.new(box, label: 'Waiting for data...')
      @stat_labels[series] = label

      box_sz = Wx::StaticBoxSizer.new(box, Wx::VERTICAL)
      box_sz.add(label, 0, Wx::ALL, 6)
      outer.add(box_sz, 0, Wx::EXPAND | Wx::ALL, 8)
    end

    @refresh_btn = Wx::Button.new(self, label: 'Refresh stats')
    @clear_btn   = Wx::Button.new(self, label: 'Clear all series')
    @status      = Wx::StaticText.new(self, label: '')

    outer.add_stretch_spacer(1)
    outer.add(@refresh_btn, 0, Wx::EXPAND | Wx::LEFT | Wx::RIGHT | Wx::BOTTOM, 8)
    outer.add(@clear_btn,   0, Wx::EXPAND | Wx::LEFT | Wx::RIGHT | Wx::BOTTOM, 8)
    outer.add(@status,      0, Wx::LEFT | Wx::BOTTOM, 8)

    set_sizer(outer)

    evt_button(@refresh_btn.id) { @on_refresh&.call }
    evt_button(@clear_btn.id)   { @on_clear&.call }
  end
end