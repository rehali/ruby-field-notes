# lib/panels/chart_panel.rb
#
# The WebView panel — hosts the Chart.js dashboard.
# Provides a clean interface for the frame to push data
# and query stats without knowing anything about WebView internals.

require_relative '../js_bridge'
require_relative '../html/dashboard_page'
require_relative '../models/sensor'

class ChartPanel < Wx::Panel
  def initialize(parent, on_ready: nil)
    super(parent)
    @on_ready = on_ready
    @ready    = false
    build_ui
    load_page
  end

  # Push a data point to a series on the chart.
  # Only works after the page signals ready.
  def push_data(series, value, label)
    return unless @ready
    @bridge.call('pushDataPoint', { series: series, value: value, label: label })
  end

  # Query stats for a series and yield the result.
  def get_stats(series, &callback)
    return unless @ready
    @bridge.call('getStats', { series: series }, &callback)
  end

  # Clear all data from a series.
  def clear_series(series)
    return unless @ready
    @bridge.call('clearSeries', { series: series })
  end

  private

  def build_ui
    @webview = Wx::WEB::WebView.new(self, Wx::ID_ANY, 'about:blank')

    sizer = Wx::VBoxSizer.new
    sizer.add(@webview, 1, Wx::EXPAND)
    set_sizer(sizer)
  end

  def load_page
    @bridge = JsBridge.new(@webview)

    # Build the page HTML from the sensor config
    config = Sensor::SERIES.transform_values do |v|
      { colour: v[:colour], unit: v[:unit] }
    end

    encoded = Base64.strict_encode64(DashboardPage.html(config))
    @webview.load_url("data:text/html;base64,#{encoded}")

    # Register handler inside evt_webview_loaded
    @webview.evt_webview_loaded(@webview.id) do
      next if @webview.current_url == 'about:blank'
      @webview.add_script_message_handler('bridge')
      # Ruby triggers ready — never rely on JS emitting it
      @bridge.run_script("RubyBridge.emit('ready', {})")
    end

    @webview.evt_webview_script_message_received(@webview.id) do |event|
      @bridge.dispatch(event.get_string)
    end

    @bridge.on('ready') do
      @ready = true
      @on_ready&.call
    end
  end
end
