# lib/html/map_page.rb
#
# The Leaflet map page as a Ruby module.
#
# Leaflet loading — two approaches shown:
#
# Approach A (used here): CDN links in the HTML.
#   Simple, always up to date, requires internet.
#   Good for development and apps that are always online.
#
# Approach B (commented out): Local files as base64 data URIs.
#   Download leaflet.js and leaflet.css to assets/, then encode them.
#   Required for offline use. See the comment in html() below.

require 'base64'

module MapPage
  JS_CLIENT = Base64.strict_encode64(
    File.read(File.join(__dir__, '../../assets/js/js_bridge_client.js'))
  )

  # To use local Leaflet assets instead of CDN, download the files:
  #   curl -o assets/js/leaflet.js  https://unpkg.com/leaflet@1.9.4/dist/leaflet.js
  #   curl -o assets/js/leaflet.css https://unpkg.com/leaflet@1.9.4/dist/leaflet.css
  #
  # Then replace the CDN links in the HTML with:
  #   LEAFLET_JS  = Base64.strict_encode64(File.read('assets/js/leaflet.js'))
  #   LEAFLET_CSS = Base64.strict_encode64(File.read('assets/js/leaflet.css'))
  #
  # And in the HTML head:
  #   <link rel="stylesheet" href="data:text/css;base64,#{LEAFLET_CSS}">
  #   <script src="data:text/javascript;base64,#{LEAFLET_JS}"></script>

  def self.html(initial_lat: -33.8688, initial_lng: 151.2093, initial_zoom: 5)
    <<~HTML
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">

        <!-- js_bridge_client.js — the JS side of the JsBridge library -->
        <script src="data:text/javascript;base64,#{JS_CLIENT}"></script>

        <!-- Leaflet from CDN — replace with local base64 for offline use -->
        <link rel="stylesheet"
              href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
        <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

        <style>
          html, body { margin: 0; padding: 0; height: 100%; }
          #map { width: 100%; height: 100%; }
        </style>
      </head>
      <body>
        <div id="map"></div>
        <script>
          // ── Map setup ───────────────────────────────────────────────────
          var map = L.map('map').setView(
            [#{initial_lat}, #{initial_lng}], #{initial_zoom}
          );

          // OpenStreetMap tiles
          L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
            maxZoom: 19
          }).addTo(map);

          var markers = {};
          var markerCount = 0;

          // ── Methods Ruby can call ───────────────────────────────────────

          RubyBridge.register('flyTo', function(p) {
            map.flyTo([p.lat, p.lng], p.zoom || 12);
            return { ok: true };
          });

          RubyBridge.register('addMarker', function(p) {
            var marker = L.marker([p.lat, p.lng]);
            if (p.label) marker.bindPopup(p.label);
            marker.addTo(map);
            markers[p.id] = marker;
            return { ok: true };
          });

          RubyBridge.register('removeMarker', function(p) {
            if (markers[p.id]) {
              map.removeLayer(markers[p.id]);
              delete markers[p.id];
            }
            return { ok: true };
          });

          RubyBridge.register('clearMarkers', function() {
            Object.keys(markers).forEach(function(id) {
              map.removeLayer(markers[id]);
            });
            markers = {};
            markerCount = 0;
            return { ok: true };
          });

          // ── Map events → Ruby ───────────────────────────────────────────

          map.on('click', function(e) {
            markerCount++;
            var id  = 'pin_' + markerCount;
            var lat = e.latlng.lat;
            var lng = e.latlng.lng;

            // Place a marker on click
            var marker = L.marker([lat, lng])
              .bindPopup('Pin ' + markerCount)
              .addTo(map);
            markers[id] = marker;

            // Notify Ruby
            RubyBridge.emit('mapClick', {
              id:  id,
              lat: lat,
              lng: lng,
              count: markerCount
            });
          });

          map.on('moveend', function() {
            var centre = map.getCenter();
            RubyBridge.emit('mapMoved', {
              lat:  centre.lat,
              lng:  centre.lng,
              zoom: map.getZoom()
            });
          });
        </script>
      </body>
      </html>
    HTML
  end
end
