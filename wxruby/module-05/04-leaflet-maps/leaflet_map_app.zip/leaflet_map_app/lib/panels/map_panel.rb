# lib/panels/map_panel.rb
#
# The WebView panel — hosts the Leaflet map.
# Provides a clean Ruby interface for the frame:
# the frame never touches WebView or JsBridge directly.

require_relative '../js_bridge'
require_relative '../html/map_page'

class MapPanel < Wx::Panel
  def initialize(parent, on_click: nil, on_moved: nil, on_ready: nil)
    super(parent)
    @on_click = on_click
    @on_moved = on_moved
    @on_ready = on_ready
    @ready    = false
    build_ui
    load_map
  end

  def fly_to(lat, lng, zoom: 12)
    return unless @ready
    @bridge.call('flyTo', { lat: lat, lng: lng, zoom: zoom })
  end

  def add_marker(id, lat, lng, label: nil)
    return unless @ready
    @bridge.call('addMarker', { id: id, lat: lat, lng: lng, label: label })
  end

  def remove_marker(id)
    return unless @ready
    @bridge.call('removeMarker', { id: id })
  end

  def clear_markers
    return unless @ready
    @bridge.call('clearMarkers', {})
  end

  private

  def build_ui
    @webview = Wx::WEB::WebView.new(self, Wx::ID_ANY, 'about:blank')
    sizer    = Wx::VBoxSizer.new
    sizer.add(@webview, 1, Wx::EXPAND)
    set_sizer(sizer)
  end

  def load_map
    @bridge = JsBridge.new(@webview)

    encoded = Base64.strict_encode64(MapPage.html)
    @webview.load_url("data:text/html;base64,#{encoded}")

    @webview.evt_webview_loaded(@webview.id) do
      next if @webview.current_url == 'about:blank'
      @webview.add_script_message_handler('bridge')
      @bridge.run_script("RubyBridge.emit('ready', {})")
    end

    @webview.evt_webview_script_message_received(@webview.id) do |event|
      @bridge.dispatch(event.get_string)
    end

    @bridge.on('ready') do
      @ready = true
      @on_ready&.call
    end

    @bridge.on('mapClick') do |payload|
      @on_click&.call(payload)
    end

    @bridge.on('mapMoved') do |payload|
      @on_moved&.call(payload)
    end
  end
end
