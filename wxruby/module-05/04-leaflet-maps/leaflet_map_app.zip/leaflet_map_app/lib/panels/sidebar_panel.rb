# lib/panels/sidebar_panel.rb
#
# The wx sidebar — city list, marker list, coordinates display.
# Communicates with the frame via callbacks.

require_relative '../models/cities'

class SidebarPanel < Wx::Panel
  def initialize(parent, on_city_selected: nil, on_remove_marker: nil,
                 on_clear_markers: nil)
    super(parent)
    @on_city_selected = on_city_selected
    @on_remove_marker = on_remove_marker
    @on_clear_markers = on_clear_markers
    @marker_ids       = []
    build_ui
  end

  def add_marker(id, lat, lng)
    @marker_ids << id
    @marker_list.append("#{id}: #{lat.round(4)}, #{lng.round(4)}")
  end

  def clear_markers
    @marker_ids.clear
    @marker_list.clear
  end

  def update_click(lat, lng)
    @click_label.label = "#{lat.round(5)}, #{lng.round(5)}"
    layout
  end

  def update_centre(lat, lng, zoom)
    @centre_label.label = "#{lat.round(4)}, #{lng.round(4)}  zoom #{zoom}"
    layout
  end

  private

  def build_ui
    # ── Cities ────────────────────────────────────────────────────────────
    city_box  = Wx::StaticBox.new(self, label: 'Fly to city')
    @city_list = Wx::ListBox.new(city_box, choices: Cities.names,
                                  style: Wx::LB_SINGLE)
    go_btn    = Wx::Button.new(city_box, label: 'Go')

    city_sz = Wx::StaticBoxSizer.new(city_box, Wx::VERTICAL)
    city_sz.add(@city_list, 1, Wx::EXPAND | Wx::ALL, 6)
    city_sz.add(go_btn,     0, Wx::EXPAND | Wx::LEFT | Wx::RIGHT | Wx::BOTTOM, 6)

    # ── Markers ───────────────────────────────────────────────────────────
    marker_box   = Wx::StaticBox.new(self, label: 'Placed markers')
    @marker_list = Wx::ListBox.new(marker_box, choices: [], style: Wx::LB_SINGLE)
    remove_btn   = Wx::Button.new(marker_box, label: 'Remove selected')
    clear_btn    = Wx::Button.new(marker_box, label: 'Clear all')

    marker_sz = Wx::StaticBoxSizer.new(marker_box, Wx::VERTICAL)
    marker_sz.add(@marker_list, 1, Wx::EXPAND | Wx::ALL, 6)
    marker_sz.add(remove_btn,  0, Wx::EXPAND | Wx::LEFT | Wx::RIGHT | Wx::BOTTOM, 6)
    marker_sz.add(clear_btn,   0, Wx::EXPAND | Wx::LEFT | Wx::RIGHT | Wx::BOTTOM, 6)

    # ── Coordinates ───────────────────────────────────────────────────────
    coords_box    = Wx::StaticBox.new(self, label: 'Coordinates')
    click_lbl     = Wx::StaticText.new(coords_box, label: 'Last click:')
    @click_label  = Wx::StaticText.new(coords_box, label: '—')
    centre_lbl    = Wx::StaticText.new(coords_box, label: 'Centre / zoom:')
    @centre_label = Wx::StaticText.new(coords_box, label: '—')

    coords_sz = Wx::StaticBoxSizer.new(coords_box, Wx::VERTICAL)
    coords_sz.add(click_lbl,    0, Wx::LEFT | Wx::TOP, 6)
    coords_sz.add(@click_label, 0, Wx::LEFT | Wx::BOTTOM, 6)
    coords_sz.add(centre_lbl,    0, Wx::LEFT, 6)
    coords_sz.add(@centre_label, 0, Wx::LEFT | Wx::BOTTOM, 6)

    # ── Layout ────────────────────────────────────────────────────────────
    outer = Wx::VBoxSizer.new
    outer.add(city_sz,   1, Wx::EXPAND | Wx::ALL, 8)
    outer.add(marker_sz, 1, Wx::EXPAND | Wx::LEFT | Wx::RIGHT | Wx::BOTTOM, 8)
    outer.add(coords_sz, 0, Wx::EXPAND | Wx::LEFT | Wx::RIGHT | Wx::BOTTOM, 8)
    set_sizer(outer)

    # ── Events ────────────────────────────────────────────────────────────
    evt_button(go_btn.id)     { on_go }
    evt_button(remove_btn.id) { on_remove }
    evt_button(clear_btn.id)  { on_clear }
    evt_listbox_dclick(@city_list.id) { on_go }
  end

  def on_go
    sel = @city_list.selection
    return if sel == Wx::NOT_FOUND
    @on_city_selected&.call(Cities.names[sel])
  end

  def on_remove
    sel = @marker_list.selection
    return if sel == Wx::NOT_FOUND
    id = @marker_ids[sel]
    @marker_ids.delete_at(sel)
    @marker_list.delete(sel)
    @on_remove_marker&.call(id)
  end

  def on_clear
    @on_clear_markers&.call
    clear_markers
  end
end
