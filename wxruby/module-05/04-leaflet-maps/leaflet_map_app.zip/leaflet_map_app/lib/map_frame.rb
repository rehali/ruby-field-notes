# lib/map_frame.rb
#
# Main frame — thin coordinator between MapPanel and SidebarPanel.

require 'base64'
require_relative 'models/cities'
require_relative 'panels/map_panel'
require_relative 'panels/sidebar_panel'

class MapFrame < Wx::Frame
  def initialize
    super(nil, title: 'Leaflet Map', size: [1100, 680])

    build_ui
    bind_events

    layout
    centre
  end

  private

  def build_ui
    @panel = Wx::Panel.new(self)

    splitter = Wx::SplitterWindow.new(@panel,
                 style: Wx::SP_3DSASH | Wx::SP_LIVE_UPDATE)

    @map_panel = MapPanel.new(splitter,
                   on_ready: method(:on_map_ready),
                   on_click: method(:on_map_click),
                   on_moved: method(:on_map_moved))

    @sidebar = SidebarPanel.new(splitter,
                 on_city_selected: method(:on_city_selected),
                 on_remove_marker: method(:on_remove_marker),
                 on_clear_markers: method(:on_clear_markers))

    splitter.split_vertically(@map_panel, @sidebar, 820)
    splitter.set_minimum_pane_size(200)

    create_status_bar
    set_status_text('Loading map...')

    sizer = Wx::VBoxSizer.new
    sizer.add(splitter, 1, Wx::EXPAND | Wx::ALL, 4)
    @panel.set_sizer(sizer)
    @panel.layout
  end

  def bind_events
    evt_close { |event| on_close(event) }
  end

  def on_map_ready
    set_status_text('Map ready — click to place markers, or choose a city')
  end

  def on_map_click(payload)
    id  = payload['id']
    lat = payload['lat'].round(5)
    lng = payload['lng'].round(5)
    @sidebar.add_marker(id, lat, lng)
    @sidebar.update_click(lat, lng)
    set_status_text("Marker placed: #{lat}, #{lng}")
  end

  def on_map_moved(payload)
    lat  = payload['lat'].to_f
    lng  = payload['lng'].to_f
    zoom = payload['zoom'].to_i
    @sidebar.update_centre(lat, lng, zoom)
  end

  def on_city_selected(name)
    city = Cities[name]
    return unless city
    @map_panel.fly_to(city[:lat], city[:lng], zoom: city[:zoom])
    set_status_text("Flying to #{name}")
  end

  def on_remove_marker(id)
    @map_panel.remove_marker(id)
    set_status_text("Removed marker #{id}")
  end

  def on_clear_markers
    @map_panel.clear_markers
    set_status_text('All markers cleared')
  end

  def on_close(event)
    event.skip
  end
end
