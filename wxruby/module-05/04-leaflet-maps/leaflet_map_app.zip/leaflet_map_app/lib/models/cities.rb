# lib/models/cities.rb
#
# Static city data — pure Ruby, no UI knowledge.

module Cities
  DATA = {
    'Sydney'      => { lat: -33.8688,  lng:  151.2093, zoom: 12 },
    'Melbourne'   => { lat: -37.8136,  lng:  144.9631, zoom: 12 },
    'Brisbane'    => { lat: -27.4698,  lng:  153.0251, zoom: 12 },
    'Auckland'    => { lat: -36.8485,  lng:  174.7633, zoom: 12 },
    'Tokyo'       => { lat:  35.6762,  lng:  139.6503, zoom: 12 },
    'London'      => { lat:  51.5074,  lng:   -0.1278, zoom: 12 },
    'New York'    => { lat:  40.7128,  lng:  -74.0060, zoom: 12 },
    'Paris'       => { lat:  48.8566,  lng:    2.3522, zoom: 12 },
    'Singapore'   => { lat:   1.3521,  lng:  103.8198, zoom: 12 },
    'Cape Town'   => { lat: -33.9249,  lng:   18.4241, zoom: 12 },
  }.freeze

  def self.names
    DATA.keys
  end

  def self.[](name)
    DATA[name]
  end
end
