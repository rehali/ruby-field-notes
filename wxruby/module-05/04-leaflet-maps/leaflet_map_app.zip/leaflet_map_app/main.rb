# main.rb
#
# Lesson 5.4 — Leaflet maps
# wxRuby3 Desktop Development Tutorial Series
#
# An interactive map with city navigation and click-to-place markers.
# Demonstrates Leaflet.js integration via JsBridge:
#   - Loading Leaflet from CDN
#   - Map events flowing to Ruby (click, moveend)
#   - Ruby controlling the map (flyTo, addMarker, clearMarkers)
#
# Run with: ruby main.rb
# Requires internet access for Leaflet CDN and map tiles.

require 'wx'
require_relative 'lib/map_frame'

Wx::App.run do
  Wx::Timer.every(25) { Thread.pass }
  MapFrame.new.show
end
