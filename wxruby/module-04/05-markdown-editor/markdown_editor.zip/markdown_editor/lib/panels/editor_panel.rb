# lib/panels/editor_panel.rb
#
# Left panel — the markdown text editor.
# Plain TextCtrl with monospace font.
# Notifies the frame on keypress via callback (lesson 3.4 pattern).

class EditorPanel < Wx::Panel
  def initialize(parent, on_change: nil)
    super(parent)
    @on_change = on_change
    build_ui
  end

  def content
    @editor.value
  end

  def content=(text)
    @editor.value = text
  end

  def clear
    @editor.clear
  end

  def set_focus
    @editor.set_focus
  end

  private

  def build_ui
    # Editor label
    editor_label = Wx::StaticText.new(self, label: 'Markdown')
    label_font = editor_label.font
    label_font.weight = Wx::FONTWEIGHT_BOLD
    editor_label.font = label_font

    @editor = Wx::TextCtrl.new(self, value: '',
                                style: Wx::TE_MULTILINE | Wx::HSCROLL | Wx::TE_DONTWRAP)

    # Monospace font makes markdown source much easier to read
    font = Wx::Font.new(14, Wx::FONTFAMILY_TELETYPE,
                        Wx::FONTSTYLE_NORMAL, Wx::FONTWEIGHT_NORMAL)
    @editor.font = font

    sizer = Wx::VBoxSizer.new
    sizer.add(editor_label, 0, Wx::ALL, 6)
    sizer.add(@editor, 1, Wx::EXPAND)
    set_sizer(sizer)

    # Register on the editor widget directly — keyboard events go to
    # the focused widget, not its parent panel (lesson 3.4)
    @editor.evt_key_up do |event|
      @on_change&.call
      event.skip
    end
  end
end
