# lib/panels/preview_panel.rb
#
# Right panel — HtmlWindow preview of the rendered markdown.
# Updated by the frame whenever the editor content changes.

class PreviewPanel < Wx::Panel
  def initialize(parent)
    super(parent)
    build_ui
  end

  # Update the preview with new HTML content
  def update(html)
    @html.set_page(html)
  end

  def clear
    @html.set_page('<html><body></body></html>')
  end

  private

  def build_ui
    # Label above the preview
    label = Wx::StaticText.new(self, label: 'Preview')
    label_font = label.font
    label_font.weight = Wx::FONTWEIGHT_BOLD
    label.font = label_font

    @html = Wx::HTML::HtmlWindow.new(self)
    @html.set_standard_fonts(13)

    # Intercept link clicks — prevent HtmlWindow navigating away
    @html.evt_html_link_clicked(@html.id) do |event|
      url = event.get_link_info.href
      # Open external links in the default browser
      Wx.launch_default_browser(url) if url.start_with?('http')
    end

    sizer = Wx::VBoxSizer.new
    sizer.add(label, 0, Wx::ALL, 6)
    sizer.add(@html, 1, Wx::EXPAND | Wx::LEFT | Wx::RIGHT | Wx::BOTTOM, 4)
    set_sizer(sizer)
  end
end
