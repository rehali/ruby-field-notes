# main.rb
#
# Markdown Editor
# wxRuby3 Desktop Development — Module 4 Capstone
#
# A side-by-side markdown editor and HTML preview.
# Type markdown on the left; the preview updates automatically.
# Open and save markdown files. Export the rendered HTML.
#
# Uses:
#   - Wx::TextCtrl for the markdown editor (lesson 3.4 pattern)
#   - Wx::HTML::HtmlWindow for the preview (lesson 4.4)
#   - kramdown with GFM for markdown conversion
#   - Wx::Timer for debounced preview updates
#   - Multi-file structure from lesson 3.2
#
# Run with: bundle exec ruby main.rb

require 'wx'
require_relative 'lib/editor_frame'

Wx::App.run { EditorFrame.new.show }
