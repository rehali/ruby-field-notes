# rich_text_demo.rb
#
# Lesson 4.3 — Rich text with Wx::RTC::RichTextCtrl
# wxRuby3 Desktop Development Tutorial Series
#
# Demonstrates:
#   - Creating and populating a RichTextCtrl
#   - Bold, italic, font size, and colour formatting
#   - Paragraph alignment and spacing
#   - Programmatic content generation
#   - Toolbar-driven formatting (user interaction)
#
# Run with: ruby rich_text_demo.rb

require 'wx'

class RichTextFrame < Wx::Frame
  def initialize
    super(nil, title: 'Rich Text Demo', size: [700, 550])

    @panel = Wx::Panel.new(self)

    build_toolbar
    build_editor
    build_layout
    bind_events

    populate_demo_content

    layout
    centre
  end

  private

  def build_toolbar
    # Simple formatting toolbar above the editor
    @bold_btn   = Wx::ToggleButton.new(@panel, label: 'B')
    @italic_btn = Wx::ToggleButton.new(@panel, label: 'I')
    @size_choice = Wx::Choice.new(@panel, choices: %w[10 11 12 14 16 18 20 24 28 32])
    @size_choice.selection = 2   # default 12pt

    bold_font = @bold_btn.font
    bold_font.weight = Wx::FONTWEIGHT_BOLD
    @bold_btn.font = bold_font

    italic_font = @italic_btn.font
    italic_font.style = Wx::FONTSTYLE_ITALIC
    @italic_btn.font = italic_font

    @toolbar_sizer = Wx::HBoxSizer.new
    @toolbar_sizer.add(Wx::StaticText.new(@panel, label: 'Size:'), 0,
                       Wx::ALIGN_CENTER_VERTICAL | Wx::RIGHT, 4)
    @toolbar_sizer.add(@size_choice, 0, Wx::ALIGN_CENTER_VERTICAL | Wx::RIGHT, 8)
    @toolbar_sizer.add(@bold_btn,   0, Wx::ALIGN_CENTER_VERTICAL | Wx::RIGHT, 4)
    @toolbar_sizer.add(@italic_btn, 0, Wx::ALIGN_CENTER_VERTICAL)
  end

  def build_editor
    # RichTextCtrl lives in the Wx::RTC namespace
    @rtc = Wx::RTC::RichTextCtrl.new(@panel,
                                     style: Wx::VSCROLL | Wx::HSCROLL | Wx::NO_BORDER | Wx::WANTS_CHARS)
  end

  def build_layout
    sizer = Wx::VBoxSizer.new
    sizer.add(@toolbar_sizer, 0, Wx::EXPAND | Wx::ALL, 8)
    sizer.add(Wx::StaticLine.new(@panel), 0, Wx::EXPAND)
    sizer.add(@rtc, 1, Wx::EXPAND | Wx::ALL, 8)
    @panel.set_sizer(sizer)
  end

  def bind_events
    evt_togglebutton(@bold_btn.id)   { on_bold }
    evt_togglebutton(@italic_btn.id) { on_italic }
    evt_choice(@size_choice.id)      { on_size_change }
  end

  # ── Formatting methods ────────────────────────────────────────────────────

  def on_bold
    @rtc.apply_bold_to_selection
    @rtc.set_focus
  end

  def on_italic
    @rtc.apply_italic_to_selection
    @rtc.set_focus
  end

  def on_size_change
    return unless @rtc.has_selection
    size = @size_choice.string_selection.to_i
    attr = Wx::RTC::RichTextAttr.new
    attr.set_font_size(size)
    @rtc.set_style_ex(@rtc.selection_range, attr, Wx::RTC::RICHTEXT_SETSTYLE_WITH_UNDO)
    @rtc.set_focus
  end

  # ── Programmatic content ──────────────────────────────────────────────────
  #
  # freeze/thaw suppress repainting during content generation —
  # essential for performance when adding many paragraphs.

  def populate_demo_content
    @rtc.freeze

    write_heading('wxRuby3 Rich Text', 22)
    write_paragraph(
      'This is a demonstration of the RichTextCtrl widget. ' \
        'It supports inline formatting like '
    )
    @rtc.begin_bold
    @rtc.write_text('bold')
    @rtc.end_bold
    @rtc.write_text(', ')
    @rtc.begin_italic
    @rtc.write_text('italic')
    @rtc.end_italic
    @rtc.write_text(', and ')
    @rtc.begin_bold
    @rtc.begin_italic
    @rtc.write_text('bold italic')
    @rtc.end_italic
    @rtc.end_bold
    @rtc.write_text('.')
    @rtc.newline

    write_heading('Text colours', 16)
    write_coloured_line('This text is red.',   Wx::Colour.new(200,   0,  0))
    write_coloured_line('This text is green.', Wx::Colour.new(  0, 150,  0))
    write_coloured_line('This text is blue.',  Wx::Colour.new(  0,  80, 200))

    write_heading('Font sizes', 16)
    [10, 12, 14, 16, 20].each do |size|
      @rtc.begin_font_size(size)
      @rtc.write_text("This text is #{size}pt.")
      @rtc.end_font_size
      @rtc.newline
    end

    write_heading('Alignment', 16)

    @rtc.begin_alignment(Wx::TEXT_ALIGNMENT_LEFT)
    @rtc.write_text('Left aligned paragraph of text. ' * 3)
    @rtc.newline
    @rtc.end_alignment

    @rtc.begin_alignment(Wx::TEXT_ALIGNMENT_CENTRE)
    @rtc.write_text('Centre aligned paragraph of text. ' * 3)
    @rtc.newline
    @rtc.end_alignment

    @rtc.begin_alignment(Wx::TEXT_ALIGNMENT_RIGHT)
    @rtc.write_text('Right aligned paragraph of text. ' * 3)
    @rtc.newline
    @rtc.end_alignment

    write_heading('Monospace / code', 16)
    @rtc.begin_font_size(12)
    font = Wx::Font.new(12, Wx::FONTFAMILY_TELETYPE,
                        Wx::FONTSTYLE_NORMAL, Wx::FONTWEIGHT_NORMAL)
    @rtc.begin_font(font)
    @rtc.write_text("def greet(name)\n  puts \"Hello, #{'{'}name{'}'}\"\nend")
    @rtc.end_font
    @rtc.end_font_size
    @rtc.newline

    @rtc.thaw
    @rtc.move_home   # scroll to top
  end

  def write_heading(text, size = 18)
    @rtc.newline if @rtc.last_position > 0
    @rtc.begin_bold
    @rtc.begin_font_size(size)
    @rtc.begin_text_colour(Wx::Colour.new(30, 30, 80))
    @rtc.write_text(text)
    @rtc.end_text_colour
    @rtc.end_font_size
    @rtc.end_bold
    @rtc.newline
  end

  def write_paragraph(text)
    @rtc.write_text(text)
  end

  def write_coloured_line(text, colour)
    @rtc.begin_text_colour(colour)
    @rtc.write_text(text)
    @rtc.end_text_colour
    @rtc.newline
  end
end

Wx::App.run { RichTextFrame.new.show }