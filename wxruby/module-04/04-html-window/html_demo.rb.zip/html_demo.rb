# html_window_demo.rb
#
# Lesson 4.4 — Wx::HTML::HtmlWindow
# wxRuby3 Desktop Development Tutorial Series
#
# Demonstrates:
#   - Creating a HtmlWindow and loading content
#   - set_page for inline HTML strings
#   - load_page for loading from a file or URL
#   - Handling link clicks
#   - Limitations vs WebView
#
# Run with: ruby html_window_demo.rb

require 'wx'

# Sample pages demonstrating different HTML features
PAGES = {
  'Typography' => <<~HTML,
    <html><body>
    <h1>Heading 1</h1>
    <h2>Heading 2</h2>
    <h3>Heading 3</h3>
    <p>A normal paragraph with <b>bold</b>, <i>italic</i>, <u>underline</u>,
    and <code>inline code</code>.</p>
    <p><font color="red">Red text</font> and
    <font color="blue">blue text</font>.</p>
    <p><big>Bigger text</big> and <small>smaller text</small>.</p>
    </body></html>
  HTML

  'Lists' => <<~HTML,
    <html><body>
    <h2>Unordered list</h2>
    <ul>
      <li>Item one</li>
      <li>Item two
        <ul>
          <li>Nested item</li>
          <li>Another nested item</li>
        </ul>
      </li>
      <li>Item three</li>
    </ul>
    <h2>Ordered list</h2>
    <ol>
      <li>First</li>
      <li>Second</li>
      <li>Third</li>
    </ol>
    </body></html>
  HTML

  'Tables' => <<~HTML,
    <html><body>
    <h2>Table</h2>
    <table border="1" cellpadding="6">
      <tr><th>Name</th><th>Age</th><th>City</th></tr>
      <tr><td>Alice</td><td>30</td><td>Sydney</td></tr>
      <tr><td>Bob</td><td>25</td><td>Melbourne</td></tr>
      <tr><td>Carol</td><td>35</td><td>Brisbane</td></tr>
    </table>
    </body></html>
  HTML

  'Code' => <<~HTML,
    <html><body>
    <h2>Code blocks</h2>
    <p>Inline: <code>Wx::HTML::HtmlWindow.new(parent)</code></p>
    <pre><code>def greet(name)
  puts "Hello, \#{name}!"
end

greet('wxRuby3')</code></pre>
    <h2>Blockquote</h2>
    <blockquote>
      The wxRuby3 toolkit provides native desktop widgets
      on macOS, Windows, and Linux.
    </blockquote>
    <hr>
    <p>A horizontal rule above.</p>
    </body></html>
  HTML

  'Links' => <<~HTML,
    <html><body>
    <h2>Links</h2>
    <p>Click a link below — the app intercepts the click
    and displays the URL in the status bar rather than
    opening a browser.</p>
    <ul>
      <li><a href="https://www.wxruby.org">wxRuby3 website</a></li>
      <li><a href="https://github.com/mcorino/wxRuby3">wxRuby3 on GitHub</a></li>
      <li><a href="page://custom-action">Custom action link</a></li>
    </ul>
    </body></html>
  HTML
}.freeze

class HtmlWindowFrame < Wx::Frame
  def initialize
    super(nil, title: 'HtmlWindow Demo', size: [750, 550])

    @panel = Wx::Panel.new(self)
    build_ui
    bind_events

    # Show first page by default
    show_page(PAGES.keys.first)

    layout
    centre
  end

  private

  def build_ui
    # Page selector
    @page_choice = Wx::Choice.new(@panel, choices: PAGES.keys)
    @page_choice.selection = 0

    # HtmlWindow — the main display area
    # It lives in the Wx::HTML namespace (note: HTML not Html)
    @html = Wx::HTML::HtmlWindow.new(@panel)

    # Set a slightly larger default font than the system default
    @html.set_standard_fonts(13)

    sizer = Wx::VBoxSizer.new
    sizer.add(@page_choice, 0, Wx::EXPAND | Wx::ALL, 8)
    sizer.add(@html,        1, Wx::EXPAND | Wx::LEFT | Wx::RIGHT | Wx::BOTTOM, 8)
    @panel.set_sizer(sizer)

    create_status_bar
    set_status_text('Select a page from the dropdown')
  end

  def bind_events
    evt_choice(@page_choice.id) do
      show_page(@page_choice.string_selection)
    end

    # Link click handler — fires when the user clicks a link.
    # Return false to allow HtmlWindow to handle it normally (open in browser).
    # Return true to indicate you have handled it yourself.
    evt_html_link_clicked(@html.id) do |event|
      url = event.get_link_info.href
      set_status_text("Link clicked: #{url}")
      # Intercept all links — prevent HtmlWindow opening them
      # In a real app you might check the URL scheme first
    end
  end

  def show_page(name)
    html = PAGES[name]
    # set_page loads an HTML string directly
    # The content must be a complete HTML document or fragment
    @html.set_page(html)
    set_status_text("Showing: #{name}")
  end
end

Wx::App.run { HtmlWindowFrame.new.show }