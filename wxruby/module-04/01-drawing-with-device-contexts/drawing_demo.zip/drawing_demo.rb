# drawing_demo.rb
#
# Lesson 4.1 — Drawing with device contexts
# wxRuby3 Desktop Development Tutorial Series
#
# Demonstrates progressive DC drawing:
#   Step 1 — blank panel with evt_paint
#   Step 2 — lines, rectangles, pens and brushes
#   Step 3 — text and fonts
#   Step 4 — bar chart from data
#
# Run with: ruby drawing_demo.rb

require 'wx'

DATA = [
  { label: 'Jan', value: 42 },
  { label: 'Feb', value: 78 },
  { label: 'Mar', value: 55 },
  { label: 'Apr', value: 91 },
  { label: 'May', value: 63 },
  { label: 'Jun', value: 87 },
].freeze

BAR_COLOURS = [
  Wx::Colour.new(70,  130, 180),
  Wx::Colour.new(60,  179, 113),
  Wx::Colour.new(255, 165,   0),
  Wx::Colour.new(220,  20,  60),
  Wx::Colour.new(147, 112, 219),
  Wx::Colour.new(64,  224, 208),
].freeze

class DrawingFrame < Wx::Frame
  def initialize
    super(nil, title: 'Drawing Demo', size: [700, 500])

    @panel = Wx::Panel.new(self)
    @panel.set_background_colour(Wx::WHITE)

    # evt_paint must be registered on the panel, not the frame.
    # It fires whenever the panel needs repainting — on first show,
    # after resize, after being uncovered by another window.
    @panel.evt_paint { on_paint }

    # Trigger a repaint whenever the window is resized.
    # Without this, the drawing won't update when the user drags the edge.
    @panel.evt_size { @panel.refresh }

    layout
    centre
  end

  private

  def on_paint
    # The paint block gives us a DC (device context) — the drawing surface.
    # All drawing must happen inside this block.
    # Never store the DC or use it outside the paint handler.
    @panel.paint do |dc|
      draw_shapes(dc)
      draw_text_samples(dc)
      draw_chart(dc)
    end
  end

  def draw_shapes(dc)
    # ── Pens and lines ────────────────────────────────────────────────────
    # A pen defines the colour and width of lines and outlines.
    dc.set_pen(Wx::Pen.new(Wx::BLACK, 1))
    dc.draw_line(10, 10, 200, 10)      # thin black line

    dc.set_pen(Wx::Pen.new(Wx::RED, 3))
    dc.draw_line(10, 20, 200, 20)      # thick red line

    # ── Rectangles ────────────────────────────────────────────────────────
    # A brush defines the fill colour of shapes.
    dc.set_pen(Wx::Pen.new(Wx::BLACK, 1))
    dc.set_brush(Wx::Brush.new(Wx::Colour.new(70, 130, 180)))
    dc.draw_rectangle(10, 35, 80, 40)   # filled blue rectangle

    # Outline only — transparent brush
    dc.set_brush(Wx::TRANSPARENT_BRUSH)
    dc.draw_rectangle(110, 35, 80, 40)  # outline only

    # ── Circles and ellipses ──────────────────────────────────────────────
    dc.set_pen(Wx::Pen.new(Wx::Colour.new(220, 20, 60), 2))
    dc.set_brush(Wx::Brush.new(Wx::Colour.new(255, 200, 200)))
    dc.draw_circle(250, 55, 30)         # x, y = centre, r = radius

    dc.set_pen(Wx::Pen.new(Wx::BLACK, 1))
    dc.set_brush(Wx::Brush.new(Wx::YELLOW))
    dc.draw_ellipse(300, 35, 100, 40)   # x, y = top-left, w, h
  end

  def draw_text_samples(dc)
    y = 90

    # Default font
    dc.set_text_foreground(Wx::BLACK)
    dc.draw_text('Default font', 10, y)

    # Bold
    dc.font = Wx::Font.new(12, Wx::FONTFAMILY_DEFAULT,
                           Wx::FONTSTYLE_NORMAL, Wx::FONTWEIGHT_BOLD)
    dc.draw_text('Bold 12pt', 150, y)

    # Italic
    dc.font = Wx::Font.new(12, Wx::FONTFAMILY_DEFAULT,
                           Wx::FONTSTYLE_ITALIC, Wx::FONTWEIGHT_NORMAL)
    dc.draw_text('Italic 12pt', 280, y)

    # Monospace
    dc.font = Wx::Font.new(11, Wx::FONTFAMILY_TELETYPE,
                           Wx::FONTSTYLE_NORMAL, Wx::FONTWEIGHT_NORMAL)
    dc.draw_text('Monospace 11pt', 420, y)

    # Coloured text
    dc.font = Wx::Font.new(13, Wx::FONTFAMILY_DEFAULT,
                           Wx::FONTSTYLE_NORMAL, Wx::FONTWEIGHT_BOLD)
    dc.set_text_foreground(Wx::Colour.new(0, 100, 200))
    dc.draw_text('Coloured text', 10, y + 25)

    # Measuring text — useful for centering labels
    dc.font = Wx::Font.new(11, Wx::FONTFAMILY_DEFAULT,
                           Wx::FONTSTYLE_NORMAL, Wx::FONTWEIGHT_NORMAL)
    dc.set_text_foreground(Wx::BLACK)
    text = 'Measured'
    tw, th = dc.get_text_extent(text)
    dc.draw_text(text, 200, y + 25)
    dc.set_pen(Wx::Pen.new(Wx::RED, 1))
    dc.set_brush(Wx::TRANSPARENT_BRUSH)
    dc.draw_rectangle(200, y + 25, tw, th)
  end

  def draw_chart(dc)
    w, _h = @panel.client_size

    # Chart area — positioned in the lower portion of the panel
    margin_left   = 50
    margin_right  = 20
    margin_top    = 150
    margin_bottom = 50
    chart_w = w - margin_left - margin_right
    chart_h = 220

    max_value = DATA.map { |d| d[:value] }.max.to_f

    # ── Title ──────────────────────────────────────────────────────────────
    dc.font = Wx::Font.new(14, Wx::FONTFAMILY_DEFAULT,
                           Wx::FONTSTYLE_NORMAL, Wx::FONTWEIGHT_BOLD)
    dc.set_text_foreground(Wx::BLACK)
    title = 'Monthly Sales'
    tw, _th = dc.get_text_extent(title)
    dc.draw_text(title, margin_left + (chart_w - tw) / 2, margin_top - 30)

    # ── Y axis gridlines and labels ────────────────────────────────────────
    dc.font = Wx::Font.new(9, Wx::FONTFAMILY_DEFAULT,
                           Wx::FONTSTYLE_NORMAL, Wx::FONTWEIGHT_NORMAL)
    5.times do |i|
      y_val = (max_value * i / 4).round
      y_pos = margin_top + chart_h - (chart_h * i / 4)

      dc.set_pen(Wx::Pen.new(Wx::Colour.new(210, 210, 210), 1))
      dc.draw_line(margin_left, y_pos, margin_left + chart_w, y_pos)

      dc.set_text_foreground(Wx::Colour.new(100, 100, 100))
      label = y_val.to_s
      lw, lh = dc.get_text_extent(label)
      dc.draw_text(label, margin_left - lw - 6, y_pos - lh / 2)
    end

    # ── Bars ───────────────────────────────────────────────────────────────
    bar_count   = DATA.length
    bar_spacing = chart_w / bar_count
    bar_width   = (bar_spacing * 0.6).to_i

    DATA.each_with_index do |item, i|
      bar_h = (chart_h * item[:value] / max_value).to_i
      bar_x = margin_left + (i * bar_spacing) + (bar_spacing - bar_width) / 2
      bar_y = margin_top + chart_h - bar_h

      # Bar
      dc.set_pen(Wx::Pen.new(BAR_COLOURS[i], 1))
      dc.set_brush(Wx::Brush.new(BAR_COLOURS[i]))
      dc.draw_rectangle(bar_x, bar_y, bar_width, bar_h)

      # Value label above bar
      dc.font = Wx::Font.new(9, Wx::FONTFAMILY_DEFAULT,
                             Wx::FONTSTYLE_NORMAL, Wx::FONTWEIGHT_BOLD)
      dc.set_text_foreground(Wx::BLACK)
      val_str = item[:value].to_s
      vw, _vh = dc.get_text_extent(val_str)
      dc.draw_text(val_str, bar_x + (bar_width - vw) / 2, bar_y - 16)

      # X axis label
      dc.font = Wx::Font.new(9, Wx::FONTFAMILY_DEFAULT,
                             Wx::FONTSTYLE_NORMAL, Wx::FONTWEIGHT_NORMAL)
      dc.set_text_foreground(Wx::Colour.new(60, 60, 60))
      lw, _lh = dc.get_text_extent(item[:label])
      dc.draw_text(item[:label],
                   bar_x + (bar_width - lw) / 2,
                   margin_top + chart_h + 6)
    end

    # ── Axes ───────────────────────────────────────────────────────────────
    dc.set_pen(Wx::Pen.new(Wx::BLACK, 2))
    dc.draw_line(margin_left, margin_top,
                 margin_left, margin_top + chart_h)
    dc.draw_line(margin_left, margin_top + chart_h,
                 margin_left + chart_w, margin_top + chart_h)
  end
end

Wx::App.run { DrawingFrame.new.show }