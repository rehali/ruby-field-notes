# main.rb
#
# Module 3 Capstone — Format Converter
# wxRuby3 Desktop Development Tutorial Series
#
# Converts between CSV, JSON, and XML formats.
# Requires: gem install nokogiri
#
# Run with: ruby main.rb

require 'wx'
require_relative 'lib/converter_frame'

Wx::App.run do
  Wx::Timer.every(25) { Thread.pass }
  ConverterFrame.new.show
end
