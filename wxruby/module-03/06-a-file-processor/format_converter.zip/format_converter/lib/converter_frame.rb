# lib/converter_frame.rb

require_relative 'panels/file_panel'
require_relative 'panels/preview_panel'

class ConverterFrame < Wx::Frame
  def initialize
    super(nil, title: 'Format Converter', size: [1000, 650])

    build_ui
    bind_events

    layout
    centre
  end

  private

  def build_ui
    @panel   = Wx::Panel.new(self)
    splitter = Wx::SplitterWindow.new(@panel, style: Wx::SP_3DSASH | Wx::SP_LIVE_UPDATE)

    @preview  = PreviewPanel.new(splitter)
    @file_pnl = FilePanel.new(splitter,
                              on_convert:      method(:on_conversion_result),
                              on_file_selected: method(:on_file_selected))

    splitter.split_vertically(@file_pnl, @preview, 300)
    splitter.set_minimum_pane_size(220)

    create_status_bar
    set_status_text('Select a file to convert')

    sizer = Wx::VBoxSizer.new
    sizer.add(splitter, 1, Wx::EXPAND | Wx::ALL, 4)
    @panel.set_sizer(sizer)
    @panel.layout
  end

  def bind_events
    evt_close { |event| on_close(event) }
  end

  def on_close(event)
    event.skip
  end

  def on_file_selected(path)
    @preview.show_original(path)
    set_status_text("Loaded: #{File.basename(path)}")
  end

  def on_conversion_result(result)
    if result.nil?
      return @preview.current_output
    end
    @preview.show_result(result)
    set_status_text("Converted: #{result.source_format} → #{result.target_format}")
    nil
  end
end
