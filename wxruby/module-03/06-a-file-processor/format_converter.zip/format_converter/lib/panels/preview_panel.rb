# lib/panels/preview_panel.rb
#
# Right panel — notebook with two tabs:
#   Original: the raw source file content
#   Converted: the converted output

class PreviewPanel < Wx::Panel
  def initialize(parent)
    super(parent)
    @current_output = nil
    build_ui
  end

  # Load and display the original file content
  def show_original(path)
    content = File.read(path, encoding: 'utf-8')
    @original.value = content
    @notebook.set_page_text(0, "Original (#{File.basename(path)})")
  rescue => e
    @original.value = "Could not read file: #{e.message}"
  end

  # Display conversion result and switch to Converted tab
  def show_result(result)
    @current_output  = result.output
    @converted.value = result.output

    lines = result.output.lines.count
    chars = result.output.length
    label = "Converted (#{result.source_format} → #{result.target_format} | #{lines} lines, #{chars} chars)"
    @notebook.set_page_text(1, label)

    notices = []
    notices << "⚠ Nested data was flattened to dot-notation keys for CSV" if result.flattened
    notices << "✓ Dot-notation keys were unflattened to nested structure"  if result.unflattened
    @notice.label = notices.join("   ")
    @notice.show(!notices.empty?)
    layout

    @notebook.selection = 1   # switch to Converted tab
  end

  def current_output
    @current_output
  end

  def clear
    @current_output  = nil
    @original.clear
    @converted.clear
    @notice.show(false)
    @notebook.set_page_text(0, 'Original')
    @notebook.set_page_text(1, 'Converted')
    layout
  end

  private

  def build_ui
    @notebook = Wx::Notebook.new(self)

    # ── Original tab ──────────────────────────────────────────────────────
    orig_page = Wx::Panel.new(@notebook)
    @original = Wx::TextCtrl.new(orig_page, value: '',
                                  style: Wx::TE_MULTILINE | Wx::TE_READONLY | Wx::HSCROLL)
    @original.font = mono_font

    orig_sizer = Wx::VBoxSizer.new
    orig_sizer.add(@original, 1, Wx::EXPAND | Wx::ALL, 4)
    orig_page.set_sizer(orig_sizer)

    @notebook.add_page(orig_page, 'Original')

    # ── Converted tab ─────────────────────────────────────────────────────
    conv_page  = Wx::Panel.new(@notebook)
    @converted = Wx::TextCtrl.new(conv_page, value: '',
                                   style: Wx::TE_MULTILINE | Wx::TE_READONLY | Wx::HSCROLL)
    @converted.font = mono_font

    conv_sizer = Wx::VBoxSizer.new
    conv_sizer.add(@converted, 1, Wx::EXPAND | Wx::ALL, 4)
    conv_page.set_sizer(conv_sizer)

    @notebook.add_page(conv_page, 'Converted')

    # ── Notice bar ────────────────────────────────────────────────────────
    @notice = Wx::StaticText.new(self, label: '')
    @notice.show(false)

    outer = Wx::VBoxSizer.new
    outer.add(@notebook, 1, Wx::EXPAND | Wx::ALL, 4)
    outer.add(@notice,   0, Wx::LEFT | Wx::BOTTOM, 8)
    set_sizer(outer)
  end

  def mono_font
    Wx::Font.new(12, Wx::FONTFAMILY_TELETYPE, Wx::FONTSTYLE_NORMAL, Wx::FONTWEIGHT_NORMAL)
  end
end
