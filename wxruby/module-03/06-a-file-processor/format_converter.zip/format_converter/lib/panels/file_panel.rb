# lib/panels/file_panel.rb
#
# Left panel — file selection, format detection and override,
# target format selection, convert and save buttons.

require_relative '../models/converter'

class FilePanel < Wx::Panel
  def initialize(parent, on_convert: nil, on_file_selected: nil)
    super(parent)
    @on_convert = on_convert
    @on_file_selected = on_file_selected
    build_ui
  end

  private

  def build_ui
    # ── File selection ───────────────────────────────────────────────────────
    file_box   = Wx::StaticBox.new(self, label: 'Source file')
    @file_path = Wx::TextCtrl.new(file_box, value: '', style: Wx::TE_READONLY)
    browse_btn = Wx::Button.new(file_box, label: 'Browse...')

    file_row = Wx::HBoxSizer.new
    file_row.add(@file_path, 1, Wx::EXPAND | Wx::RIGHT, 6)
    file_row.add(browse_btn, 0)

    file_sizer = Wx::StaticBoxSizer.new(file_box, Wx::VERTICAL)
    file_sizer.add(file_row, 0, Wx::EXPAND | Wx::ALL, 8)

    # ── Format selection ─────────────────────────────────────────────────────
    fmt_box = Wx::StaticBox.new(self, label: 'Formats')

    src_label    = Wx::StaticText.new(fmt_box, label: 'Source:')
    @source_fmt  = Wx::Choice.new(fmt_box, choices: ['Auto-detect'] + Converter::FORMATS)
    @source_fmt.selection = 0

    tgt_label    = Wx::StaticText.new(fmt_box, label: 'Target:')
    @target_fmt  = Wx::Choice.new(fmt_box, choices: Converter::FORMATS)
    @target_fmt.selection = 1   # default to JSON

    fmt_grid = Wx::FlexGridSizer.new(0, 2, 8, 12)
    fmt_grid.add_growable_col(1)
    fmt_grid.add(src_label,   0, Wx::ALIGN_CENTER_VERTICAL)
    fmt_grid.add(@source_fmt, 1, Wx::EXPAND)
    fmt_grid.add(tgt_label,   0, Wx::ALIGN_CENTER_VERTICAL)
    fmt_grid.add(@target_fmt, 1, Wx::EXPAND)

    fmt_sizer = Wx::StaticBoxSizer.new(fmt_box, Wx::VERTICAL)
    fmt_sizer.add(fmt_grid, 0, Wx::EXPAND | Wx::ALL, 8)

    # ── Action buttons ────────────────────────────────────────────────────────
    @convert_btn = Wx::Button.new(self, label: 'Convert')
    @save_btn    = Wx::Button.new(self, label: 'Save output...')
    @convert_btn.enable(false)
    @save_btn.enable(false)

    btn_sizer = Wx::VBoxSizer.new
    btn_sizer.add(@convert_btn, 0, Wx::EXPAND | Wx::BOTTOM, 6)
    btn_sizer.add(@save_btn,    0, Wx::EXPAND)

    # ── Status ────────────────────────────────────────────────────────────────
    @status = Wx::StaticText.new(self, label: 'No file selected')

    # ── Outer layout ─────────────────────────────────────────────────────────
    outer = Wx::VBoxSizer.new
    outer.add(file_sizer, 0, Wx::EXPAND | Wx::ALL, 8)
    outer.add(fmt_sizer,  0, Wx::EXPAND | Wx::LEFT | Wx::RIGHT | Wx::BOTTOM, 8)
    outer.add(btn_sizer,  0, Wx::EXPAND | Wx::LEFT | Wx::RIGHT | Wx::BOTTOM, 8)
    outer.add_stretch_spacer(1)
    outer.add(@status, 0, Wx::ALL, 8)
    set_sizer(outer)

    # ── Events ────────────────────────────────────────────────────────────────
    evt_button(browse_btn.id)   { on_browse }
    evt_button(@convert_btn.id) { on_convert }
    evt_button(@save_btn.id)    { on_save }
  end

  def on_browse
    dialog = Wx::FileDialog.new(
      self, 'Open file', '', '',
      'All supported (*.csv;*.json;*.xml)|*.csv;*.xml;*.json|' \
      'CSV files (*.csv)|*.csv|' \
      'JSON files (*.json)|*.json|' \
      'XML files (*.xml)|*.xml|' \
      'All files (*.*)|*.*',
      Wx::FD_OPEN | Wx::FD_FILE_MUST_EXIST
    )

    if dialog.show_modal == Wx::ID_OK
      @file_path.value = dialog.path
      auto_detect_format(dialog.path)
      @convert_btn.enable(true)
      @save_btn.enable(false)
      @status.label = "File: #{File.basename(dialog.path)}"
      @on_file_selected&.call(dialog.path)
    end

    dialog.destroy
  end

  def auto_detect_format(path)
    detected = Converter.detect_format(path)
    if detected
      # Set source choice to the detected format
      idx = Converter::FORMATS.index(detected)
      @source_fmt.selection = idx + 1   # +1 because 'Auto-detect' is index 0
      # Set a sensible default target — first format that isn't the source
      default_target = Converter::FORMATS.find { |f| f != detected }
      @target_fmt.selection = Converter::FORMATS.index(default_target)
    else
      @source_fmt.selection = 0   # back to Auto-detect
    end
  end

  def on_convert
    path = @file_path.value
    return if path.empty?

    # Resolve source format
    source = if @source_fmt.selection == 0
               Converter.detect_format(path) || begin
                 Wx::message_box('Cannot detect format. Please select manually.',
                                 'Unknown format', Wx::OK | Wx::ICON_WARNING)
                 return
               end
             else
               Converter::FORMATS[@source_fmt.selection - 1]
             end

    target = Converter::FORMATS[@target_fmt.selection]

    if source == target
      Wx::message_box('Source and target formats are the same.',
                      'Nothing to convert', Wx::OK | Wx::ICON_INFORMATION)
      return
    end

    @status.label = 'Converting...'
    @convert_btn.enable(false)

    panel = self
    @worker = Thread.new do
      result = Converter.new(path, source, target).convert
      panel.call_after { panel.send(:conversion_complete, result) }
    end
  end

  def conversion_complete(result)
    @convert_btn.enable(true)
    if result.success
      @status.label = "Converted: #{result.source_format} → #{result.target_format}"
      @save_btn.enable(true)
      @on_convert&.call(result)
    else
      @status.label = 'Conversion failed'
      Wx::message_box("Conversion failed:\n#{result.error}", 'Error',
                      Wx::OK | Wx::ICON_ERROR)
    end
  end

  def on_save
    # Ask on_convert callback for the current output
    result = @on_convert&.call(nil)   # nil signals "give me the current output"
    return unless result

    ext = @target_fmt.string_selection.downcase
    dialog = Wx::FileDialog.new(
      self, 'Save output', File.dirname(@file_path.value),
      File.basename(@file_path.value, '.*') + ".#{ext}",
      "#{@target_fmt.string_selection} files (*.#{ext})|*.#{ext}",
      Wx::FD_SAVE | Wx::FD_OVERWRITE_PROMPT
    )

    if dialog.show_modal == Wx::ID_OK
      File.write(dialog.path, result)
      @status.label = "Saved: #{File.basename(dialog.path)}"
    end

    dialog.destroy
  end
end
