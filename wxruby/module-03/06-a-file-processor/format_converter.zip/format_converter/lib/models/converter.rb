# lib/models/converter.rb
#
# Handles all format detection, parsing, and conversion.
# No UI knowledge — pure Ruby data transformation.
#
# CSV is a flat format. When converting from JSON or XML to CSV,
# nested structures are flattened using dot-notation keys:
#   { "address" => { "city" => "Sydney" } }
#   becomes: "address.city" => "Sydney"
#
# When converting dot-notation CSV back to JSON or XML,
# the nesting is reconstructed automatically.

require 'csv'
require 'json'
require 'nokogiri'

class Converter
  FORMATS = %w[CSV JSON XML].freeze

  ConversionResult = Struct.new(:success, :output, :error,
                                :source_format, :target_format,
                                :flattened, :unflattened)

  def self.detect_format(path)
    case File.extname(path).downcase
    when '.csv'  then 'CSV'
    when '.json' then 'JSON'
    when '.xml'  then 'XML'
    else nil
    end
  end

  def initialize(path, source_format, target_format)
    @path          = path
    @source_format = source_format
    @target_format = target_format
  end

  def convert
    input       = File.read(@path, encoding: 'utf-8')
    data        = parse(input)
    flattened   = @target_format == 'CSV' && nested?(data)
    unflattened = @source_format == 'CSV' && @target_format != 'CSV' &&
                  data.any? { |r| r.keys.any? { |k| k.include?('.') } }
    flat_data   = flattened ? data.map { |r| flatten_record(r) } : data
    output      = serialize(flat_data)
    ConversionResult.new(true, output, nil, @source_format, @target_format,
                         flattened, unflattened)
  rescue => e
    ConversionResult.new(false, nil, e.message, @source_format, @target_format,
                         false, false)
  end

  private

  # ── Nesting helpers ───────────────────────────────────────────────────────

  def nested?(data)
    data.any? { |r| r.values.any? { |v| v.is_a?(Hash) || v.is_a?(Array) } }
  end

  # Flatten a nested hash to dot-notation keys
  def flatten_record(record, prefix = '')
    record.each_with_object({}) do |(key, value), result|
      full_key = prefix.empty? ? key.to_s : "#{prefix}.#{key}"
      case value
      when Hash
        result.merge!(flatten_record(value, full_key))
      when Array
        result[full_key] = value.map { |v| v.is_a?(Hash) ? v.to_json : v.to_s }.join('; ')
      else
        result[full_key] = value.to_s
      end
    end
  end

  # Reconstruct nested hash from dot-notation keys
  def unflatten_record(flat)
    flat.each_with_object({}) do |(key, value), result|
      parts = key.split('.')
      if parts.length == 1
        result[key] = value
      else
        target = result
        parts[0..-2].each do |part|
          target[part] ||= {}
          target = target[part]
        end
        target[parts.last] = value
      end
    end
  end

  # ── Parse / Serialize ─────────────────────────────────────────────────────

  def parse(input)
    case @source_format
    when 'CSV'  then parse_csv(input)
    when 'JSON' then parse_json(input)
    when 'XML'  then parse_xml(input)
    else raise "Unknown source format: #{@source_format}"
    end
  end

  def serialize(data)
    case @target_format
    when 'CSV'  then serialize_csv(data)
    when 'JSON' then serialize_json(data)
    when 'XML'  then serialize_xml(data)
    else raise "Unknown target format: #{@target_format}"
    end
  end

  # ── Parsers ───────────────────────────────────────────────────────────────

  def parse_csv(input)
    rows = CSV.parse(input, headers: true)
    rows.map { |row| unflatten_record(row.to_h) }
  end

  def parse_json(input)
    data = JSON.parse(input)
    data.is_a?(Array) ? data : [data]
  end

  def parse_xml(input)
    doc     = Nokogiri::XML(input) { |config| config.strict }
    records = doc.root.children.select(&:element?)
    records.map { |node| parse_xml_node(node) }
  end

  def parse_xml_node(node)
    children = node.children.select(&:element?)
    if children.empty?
      node.text
    else
      children.each_with_object({}) do |child, hash|
        existing = hash[child.name]
        value    = parse_xml_node(child)
        if existing
          hash[child.name] = Array(existing) << value
        else
          hash[child.name] = value
        end
      end
    end
  end

  # ── Serializers ───────────────────────────────────────────────────────────

  def serialize_csv(data)
    return '' if data.empty?
    headers = data.first.keys
    CSV.generate do |csv|
      csv << headers
      data.each { |row| csv << headers.map { |h| row[h] } }
    end
  end

  def serialize_json(data)
    JSON.pretty_generate(data)
  end

  def serialize_xml(data)
    builder = Nokogiri::XML::Builder.new(encoding: 'UTF-8') do |xml|
      xml.records do
        data.each do |record|
          xml.record { build_xml_node(xml, record) }
        end
      end
    end
    builder.to_xml
  end

  def build_xml_node(xml, value, key = nil)
    case value
    when Hash
      value.each do |k, v|
        safe_key = sanitize_xml_key(k)
        xml.send(safe_key) { build_xml_node(xml, v) }
      end
    when Array
      value.each do |item|
        safe_key = key ? sanitize_xml_key(key) : 'item'
        xml.send(safe_key) { build_xml_node(xml, item) }
      end
    else
      xml.text(value.to_s)
    end
  end

  def sanitize_xml_key(key)
    key.to_s.gsub(/[^a-zA-Z0-9_-]/, '_').sub(/\A\d/, '_\0')
  end
end
