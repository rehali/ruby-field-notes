# main.rb
#
# Module 3 Lesson 3.2 — Application Structure
# wxRuby3 Desktop Development Tutorial Series
#
# A city browser demonstrating multi-file app structure
# and inter-panel communication via callbacks.
#
# Run with: ruby main.rb

require 'wx'
require_relative 'lib/app_frame'

Wx::App.run { AppFrame.new.show }
