# lib/panels/sidebar_panel.rb

class SidebarPanel < Wx::Panel
  CITIES = [
    'Paris', 'Tokyo', 'New York', 'Sydney', 'London',
    'Cairo', 'Buenos Aires', 'Toronto', 'Mumbai', 'Berlin'
  ].freeze

  def initialize(parent, on_select: nil)
    super(parent)
    @on_select = on_select
    set_min_size(Wx::Size.new(160, -1))
    build_ui
  end

  private

  def build_ui
    label   = Wx::StaticText.new(self, label: 'Cities')
    @list   = Wx::ListBox.new(self, choices: CITIES.dup,
                               style: Wx::LB_SINGLE | Wx::BORDER_SUNKEN)
    add_btn = Wx::Button.new(self, label: 'Add')
    rem_btn = Wx::Button.new(self, label: 'Remove')

    btn_row = Wx::HBoxSizer.new
    btn_row.add(add_btn, 1, Wx::RIGHT, 4)
    btn_row.add(rem_btn, 1)

    sizer = Wx::VBoxSizer.new
    sizer.add(label,   0, Wx::ALL, 8)
    sizer.add(@list,   1, Wx::EXPAND | Wx::LEFT | Wx::RIGHT, 8)
    sizer.add(btn_row, 0, Wx::EXPAND | Wx::ALL, 8)
    set_sizer(sizer)

    evt_listbox(@list.id)  { on_city_selected }
    evt_button(add_btn.id) { on_add }
    evt_button(rem_btn.id) { on_remove }
  end

  def on_city_selected
    sel = @list.selection
    return if sel == Wx::NOT_FOUND
    @on_select&.call(@list.string(sel))
  end

  def on_add
    dialog = Wx::TextEntryDialog.new(self, 'Enter city name:', 'Add City')
    if dialog.show_modal == Wx::ID_OK && !dialog.value.empty?
      @list.append(dialog.value)
    end
    dialog.destroy
  end

  def on_remove
    sel = @list.selection
    @list.delete(sel) if sel != Wx::NOT_FOUND
    @on_select&.call(nil)
  end
end
