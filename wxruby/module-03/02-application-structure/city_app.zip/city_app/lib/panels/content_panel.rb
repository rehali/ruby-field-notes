# lib/panels/content_panel.rb

CITY_DATA = {
  'Paris'        => { country: 'France',    population: '2.1 million',  language: 'French' },
  'Tokyo'        => { country: 'Japan',     population: '13.9 million', language: 'Japanese' },
  'New York'     => { country: 'USA',       population: '8.3 million',  language: 'English' },
  'Sydney'       => { country: 'Australia', population: '5.3 million',  language: 'English' },
  'London'       => { country: 'UK',        population: '9.0 million',  language: 'English' },
  'Cairo'        => { country: 'Egypt',     population: '10.1 million', language: 'Arabic' },
  'Buenos Aires' => { country: 'Argentina', population: '3.1 million',  language: 'Spanish' },
  'Toronto'      => { country: 'Canada',    population: '2.9 million',  language: 'English' },
  'Mumbai'       => { country: 'India',     population: '20.7 million', language: 'Marathi' },
  'Berlin'       => { country: 'Germany',   population: '3.7 million',  language: 'German' },
}.freeze

class ContentPanel < Wx::Panel
  def initialize(parent)
    super(parent)
    build_ui
    show_city(nil)
  end

  def show_city(name)
    if name.nil?
      @title.label      = 'Select a city'
      @separator.show(false)
      @country.label    = ''
      @population.label = ''
      @language.label   = ''
    else
      data = CITY_DATA[name] || { country: 'Unknown', population: 'Unknown', language: 'Unknown' }
      @title.label      = name
      @separator.show(true)
      @country.label    = data[:country]
      @population.label = data[:population]
      @language.label   = data[:language]
    end
    layout
  end

  private

  def build_ui
    # Outer panel with sunken border acts as the content area border
    @body = Wx::Panel.new(self, style: Wx::BORDER_SUNKEN)

    @title = Wx::StaticText.new(@body, label: '')
    title_font = @title.font
    title_font.weight     = Wx::FONTWEIGHT_BOLD
    title_font.point_size = title_font.point_size + 4
    @title.font = title_font

    @separator = Wx::StaticLine.new(@body)
    @separator.show(false)

    # Detail labels
    detail_font = self.font
    detail_font.point_size = detail_font.point_size + 1

    country_lbl    = Wx::StaticText.new(@body, label: 'Country:')
    population_lbl = Wx::StaticText.new(@body, label: 'Population:')
    language_lbl   = Wx::StaticText.new(@body, label: 'Language:')

    @country    = Wx::StaticText.new(@body, label: '')
    @population = Wx::StaticText.new(@body, label: '')
    @language   = Wx::StaticText.new(@body, label: '')

    [country_lbl, population_lbl, language_lbl,
     @country, @population, @language].each do |w|
      w.font = detail_font
    end

    grid = Wx::FlexGridSizer.new(0, 2, 10, 16)
    grid.add_growable_col(1)
    grid.add(country_lbl,    0, Wx::ALIGN_CENTER_VERTICAL)
    grid.add(@country,       1, Wx::EXPAND)
    grid.add(population_lbl, 0, Wx::ALIGN_CENTER_VERTICAL)
    grid.add(@population,    1, Wx::EXPAND)
    grid.add(language_lbl,   0, Wx::ALIGN_CENTER_VERTICAL)
    grid.add(@language,      1, Wx::EXPAND)

    body_sizer = Wx::VBoxSizer.new
    body_sizer.add(@title,     0, Wx::ALL, 12)
    body_sizer.add(@separator, 0, Wx::EXPAND | Wx::LEFT | Wx::RIGHT, 12)
    body_sizer.add(grid,       0, Wx::EXPAND | Wx::ALL, 12)
    @body.set_sizer(body_sizer)

    outer = Wx::VBoxSizer.new
    outer.add(@body, 1, Wx::EXPAND | Wx::ALL, 8)
    set_sizer(outer)
  end
end
