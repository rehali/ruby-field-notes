# lib/app_frame.rb

require_relative 'panels/sidebar_panel'
require_relative 'panels/content_panel'

class AppFrame < Wx::Frame
  def initialize
    super(nil, title: 'City Browser', size: [600, 400])

    build_ui
    bind_events

    layout
    centre
  end

  private

  def build_ui
    @panel   = Wx::Panel.new(self)
    splitter = Wx::SplitterWindow.new(@panel,
                 style: Wx::SP_3DSASH | Wx::SP_LIVE_UPDATE)

    @content = ContentPanel.new(splitter)
    @sidebar = SidebarPanel.new(splitter, on_select: method(:on_city_selected))

    splitter.split_vertically(@sidebar, @content, 200)
    splitter.set_minimum_pane_size(160)

    sizer = Wx::VBoxSizer.new
    sizer.add(splitter, 1, Wx::EXPAND)
    @panel.set_sizer(sizer)
  end

  def bind_events
    evt_close { |event| on_close(event) }
  end

  def on_close(event)
    event.skip
  end

  def on_city_selected(city)
    @content.show_city(city)
  end
end
